/**
 * @file    app.c
 * @author  Andrea Pedrana - andrea.pedrana@unibg.it
 * @version 1.0
 * @date    17 July 2018
 * @brief   Log functions header and definitions
 * @details Edit this file at your own risk
 * Universit� degli studi di Bergamo, Microlab
 */



#ifndef LOG_H_
#define LOG_H_

#include "stdint.h"
#include "stdbool.h"
#include "app.h"
#include "stm32l4xx_hal.h"

#define SD_BLOCK_SIZE 		512

#define LITTLE_BLOCKS		1 //FIXME: for now only 1 is allowed

#define LITTLE_SIZE			1024

#define BIG_BLOCKS			10

#define BIG_SIZE			(SD_BLOCK_SIZE*BIG_BLOCKS + 300)


void Log_Init(void);

void Log_logData(void);

void copySampleInBuffer(uint8_t*, uint16_t*);

void MemToMemTxCplt(DMA_HandleTypeDef *);

void gestisciInt();


#endif
