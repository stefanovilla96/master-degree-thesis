/**
 * @file    app.h
 * @author  Andrea Pedrana - andrea.pedrana@unibg.it
 * @version 1.0
 * @date    17 July 2018
 * @brief   Header file of main application
 * @details Edit this file at your own risk
 * Universit� degli studi di Bergamo, Microlab
 */

#ifndef __APP_H
#define __APP_H

#include "stdint.h"
#include "stdbool.h"
#include "modules/LSM6DSL/LSM6DSL.h"

#include "AD5940/BodyImpedance.h"
//	VECT (rx)		:ORIGIN = 0x08020000, LENGTH = 512
//	FLASH (rx)      : ORIGIN = 0x08020200, LENGTH = 256K
//	RAM (xrw)      : ORIGIN = 0x20000000, LENGTH = 128K
int contatore;

// operazioni schedulate che andranno eseguite
typedef enum {
	OP_NONE=0x00, OP_SHUTDOWN=0x01, OP_RESTART=0x02
} ScheduledOp;

// possibili stati del sistema
typedef enum {
	APP_IDLE=0x01,		//!< APP_IDLE
	APP_STARTUP=0x02,	//!< APP_STARTUP
	APP_STOP=0x03,      //!< APP_STOP
	APP_LOG=0x04,		//!< APP_LOG
	APP_ERROR=0xFF		//!< APP_ERROR
} SystemState;

typedef enum{
	MODE_AXL=0x00,
	MODE_GYRO=0x01,
	MODE_AXL_GYRO=0x02,
	MODE_BIA=0x03
}Mode_Typedef;

typedef struct {
	uint16_t frequency;				// Main job frequency
	ScheduledOp scheduledOperation;
	uint16_t appPeriod;
	uint64_t lastActivityTime;
	uint16_t acc_sample[3];        	// Vettore di 6 bytes x, y e z accelerometro (2 bytes per asse)
	uint16_t gyro_sample[3];
	uint16_t temperature;

	fImpPol_Type BIA_sample; //8 byte

	SystemState state;
	bool end_log_buffer;			// Check end log buffer
	bool card_mounted;
	Mode_Typedef acq_mode;
	uint32_t tempTick;
//TODO LIS2DH_FullScale axlFS;	// Accelerometer full scale
	bool lp_run;
} Winter_TypeDef;

typedef enum {
	RESTART_RESET=0x00, RESTART_BOOT_LOADER=0x01 //TODO
} RestartMode;



////-----------IRQn definitions---------
#define APP_JOB_IRQn				TIM3_IRQn

#define APP_JOB_IRQn_Priority		5

#define ACQ_JOB_IRQn				TIM4_IRQn

#define ACQ_JOB_IRQn_Priority		2

////-----------PERIODS and TIMEOUTS------------------

#define APP_LOG_PERIOD					40 //FIXME: for now 25 Hz

#define APP_DATA_SAMPLING_PERIOD		30

#define APP_IDLE_PERIOD					100

#define APP_ERROR_PERIOD				1000

#define APP_IDLE_TIMEOUT				1000000 //TODO: Timeout in ms

#define RESTART_SHUTDOWN_DELAY			2000

#define MAX_ACQ_FREQUENCY				1000 //Maximum acquisition frequency

/**
 * Initializes the system and loads everything needed
 */
void initSystem(void);

/**
 * Initialize the sensor embedded in the main board
 */
void initMainSensors(void);

/**
 *
 * @param arg, the period to be set
 */
void setAppPeriod(uint16_t arg);

/**
 *
 * @return the application period
 */
uint16_t getAppPeriod(void);

/**
 * carries out the application job
 */
void doJob(void);

/**
 *
 * @return the current state of the system
 */
SystemState getSystemState(void);

/**
 *
 * @param s, the state to be set
 */
bool setSystemState(SystemState s);

/**
 * Shuts down the system
 */
void shutDown(void);

/**
 * Returns the epoch [ms] of the last activity
 */
void updateLastActivityTime(void);

void updateData(void);

void setScheduledOperation(ScheduledOp operation);

void setAcquisitionMode(Mode_Typedef acqm);



#endif
