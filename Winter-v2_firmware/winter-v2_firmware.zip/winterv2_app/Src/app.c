/**
 * @file    app.c
 * @author  Andrea Pedrana - andrea.pedrana@unibg.it
 * @version 1.0
 * @date    17 July 2018
 * @brief   Implementation of main application
 * @details Edit this file at your own risk
 * Universit� degli studi di Bergamo, Microlab
 */

#include "app.h"
#include "main.h"

#include "IO/io.h"

/// Include mainboard sensors libraries
#include "LSM6DSL/LSM6DSL.h"
#include "HTS221/HTS221.h"
#include "LPS22HH/LPS22HH.h"
#include "MAX17048/MAX17048.h"

/// Include expansion board libraries
#include "AD5940/ad5940_st.h"

#include "fatfs.h"
#include "string.h"
#include "log.h"
#include "BLE/ble.h"
#include "GattDB/gatt_db.h"
#include "BlueNRG/includes/bluenrg_aci.h"
#include "BlueNRG/includes/stm32_bluenrg_ble.h"

#include "AD5940/BodyImpedance.h"
Winter_TypeDef winter;

const char fw_version[]="1.0.0"; // MAJOR.MINOR.PATCH

extern DMA_HandleTypeDef hdma_memtomem_dma2_channel1;

FATFS FatFsDisk; /* File system object for User logical drive */
extern char SDPath[4];

bool oneshot=false;
int contatore=0;

extern SPI_HandleTypeDef hspi1;

/**
 * Initializes the system and loads everything needed
 */
void initSystem(void){

	setSystemState(APP_STARTUP);

	/// Variables initialization
	winter.scheduledOperation=OP_NONE;

	memset(winter.acc_sample,0,6);

	winter.appPeriod= APP_IDLE_PERIOD;

	winter.lp_run=false;

	/// Sensors initialization
	initMainSensors();

	// Humidity sensor initialization
	if(HTS221_Check_Who_Am_I()){
		HTS221_Config();
	}
	winter.tempTick=HAL_GetTick();

	/// Enable LDO
	setLDO(true);
	/// Tight high reset pins
	AD5940_RstSet();
	HAL_Delay(100);

	uint8_t isConnected = checkAD5940Communication();

	// FIXME
	if(isConnected){
		setSystemState(APP_IDLE);
	}else{
		setSystemState(APP_ERROR);
	}

	// if comm is ok, go to idle state. Otherwise ERROR.
	/// FIXME Register DMA Callback for Mem2Mem DMA Transfer
	//	void (*funPtr)(DMA_HandleTypeDef*);
	//	funPtr=&MemToMemTxCplt;
	//	HAL_DMA_RegisterCallback(&hdma_memtomem_dma2_channel1,HAL_DMA_XFER_CPLT_CB_ID,funPtr);
	/// Communication and memory initialization
	setVcc(true);

	HAL_Delay(500);

	// SD Card Init
	BSP_SD_Init();
	if(f_mount(&FatFsDisk,SDPath,1) == FR_OK){ // Try to mount SDcard
		winter.card_mounted= true;
	}else{
		winter.card_mounted= false;
	}

	// TODO BLE Init
	BLE_init();


	/// Register and set priority of main job interrupt
	HAL_NVIC_SetPriority(APP_JOB_IRQn,APP_JOB_IRQn_Priority,0);
	HAL_NVIC_EnableIRQ(APP_JOB_IRQn);

	/// Register and set priority of acquisition job interrupt
	HAL_NVIC_SetPriority(ACQ_JOB_IRQn,ACQ_JOB_IRQn_Priority,0);
	HAL_NVIC_EnableIRQ(ACQ_JOB_IRQn);


	// End initialization
	setAcquisitionMode(MODE_BIA);
	setSystemState(APP_LOG);

	// FIXME
	// Add low power modes (see project on microlab pc)
}

void initMainSensors(void){
	/// LSM6DSL init and check
	LSM6DSL_Init_TypeDef ag_config;
	ag_config.comm_interface=LSM6DSL_SPI_4WIRES;
	ag_config.axl_bw0=LSM6DSL_REG_CTRL1_BW0_400Hz;
	ag_config.axl_fs=LSM6DSL_REG_CTRL1_FS_8g; // TODO
	ag_config.axl_lpf=LSM6DSL_REG_CTRL1_XL_LPF1_DISABLE;
	ag_config.axl_odr=LSM6DSL_ODR_104Hz; // TODO
	ag_config.bdu=LSM6DSL_REG_CTRL3_BDU_BLOCKING;
	ag_config.gyro_fs=LSM6DSL_REG_CTRL2_G_FS_1000dps;
	ag_config.gyro_odr=LSM6DSL_ODR_104Hz; // TODO
	LSM6DSL_Config(ag_config);
	LSM6DSL_check_WhoAmI();

	/// Put LSM6DSM in power-down mode
	LSM6DSL_axl_power_down(true);
	LSM6DSL_gyro_power_down(true);
}

/**
 *
 * @param arg, the period to be set
 */
void setAppPeriod(uint16_t arg){
	winter.appPeriod=arg;
}

/**
 *
 * @return the application period
 */
uint16_t getAppPeriod(void){
	return winter.appPeriod;
}

/**
 * carries out the application job
 */
void doJob(){

	switch(winter.state){
	case APP_ERROR:
		break;
	case APP_STARTUP:
		break;
	case APP_IDLE:
		contatore++;
		if(contatore % 12 == 0){
			contatore=1;
			LED_Toggle(LED_BLUE);
		}
		break;
	case APP_LOG:
		AD5940_BIAMeasure();
		Log_logData();
		contatore++;
		if(contatore % 6 == 0){
			contatore=1;
			//				LED_Toggle(LED_ORANGE);
		}
		break;
	default:
		break;
	}

	//Handle scheduled operations
	if(winter.scheduledOperation != OP_NONE){
		switch(winter.scheduledOperation){
		case OP_SHUTDOWN:
			if(HAL_GetTick() - winter.lastActivityTime >= RESTART_SHUTDOWN_DELAY){

			}
			break;
		case OP_RESTART:
			if(HAL_GetTick() - winter.lastActivityTime >= RESTART_SHUTDOWN_DELAY){
				HAL_NVIC_SystemReset();
			}
			break;
		default:
			break;
		}
	}

	if(HAL_GetTick() - winter.tempTick >= 10000 && getSystemState() == APP_IDLE){
		winter.tempTick=HAL_GetTick();
		winter.temperature=(int16_t)(HTS221_readOut_Temperature() * 100);
		updateTemperature(winter.temperature);
	}
}

/**
 *
 * @return the current state of the system
 */
SystemState getSystemState(void){
	return winter.state;
}

bool setSystemState(SystemState new_state){

	if(new_state == getSystemState())
		return true;

	switch(getSystemState()){
	case APP_IDLE:
		LED_Cmd(LED_BLUE,false);
		LED_Cmd(LED_RED,false);
		break;
	case APP_STARTUP:
		LED_Cmd(LED_BLUE,false);
		LED_Cmd(LED_RED,false);
		break;
	default:
		break;
	}

	switch(new_state){
	case APP_STARTUP:
		LED_Cmd(LED_RED,true);
		LED_Cmd(LED_BLUE,false);
		LED_Cmd(LED_GREEN,false);
		break;
	case APP_STOP:
		HAL_PWR_DisableSleepOnExit();
		LED_Cmd(LED_BLUE,false);
		LED_Cmd(LED_RED,true);
		break;
	case APP_IDLE:
		// TODO: if AD5940 is on, power it down
		LED_Cmd(LED_RED,false);
		LED_Cmd(LED_BLUE,false);
		setAppPeriod(APP_IDLE_PERIOD);
		break;
	case APP_ERROR:
		setAppPeriod(APP_ERROR_PERIOD);
		break;
	case APP_LOG:
		// TODO: AD5940 on
		Log_Init();
		AD5940_BIAInit();
		setAppPeriod(APP_LOG_PERIOD);

		break;
	default:
		return false;
	}

	updateLastActivityTime();
	winter.state=new_state;
	return true;
}

void updateLastActivityTime(void){
	winter.lastActivityTime=HAL_GetTick();
}

void setScheduledOperation(ScheduledOp operation){
	winter.scheduledOperation=operation;
}

void updateData(void){
	float acc[3];
	float gyro[3];
	LSM6DSL_read_axl(acc,winter.acc_sample);
	LSM6DSL_read_gyro(gyro,winter.gyro_sample);
}

void setAcquisitionMode(Mode_Typedef acqm){
	winter.acq_mode=acqm;
}
