/**
 * @file    app.c
 * @author  Andrea Pedrana - andrea.pedrana@unibg.it
 * @version 1.0
 * @date    17 July 2018
 * @brief   Implementation of log functions
 * @details Edit this file at your own risk
 * Universit� degli studi di Bergamo, Microlab
 */

#include "IO/io.h"
#include "log.h"
#include "main.h"
#include "app.h"
#include "fatfs.h"
#include "string.h"
#include "GattDB/comm.h"
#include "AD5940/AD5940Main.h"
#include "AD5940/BodyImpedance.h"

volatile uint16_t logIndex=0;
volatile uint16_t lastCopyIndex = 0;

extern uint8_t frequency;

extern volatile Winter_TypeDef winter;
extern DMA_HandleTypeDef hdma_memtomem_dma2_channel1;

bool end_log_buffer= false;
uint8_t wr_p,rd_p;
uint8_t num_samples;
uint8_t samples[288];
uint16_t pointbig = 0;

volatile uint8_t little[LITTLE_SIZE];

//volatile uint8_t big[BIG_SIZE];

extern char SDPath[4];

extern LSM6DSL_Init_TypeDef ag_init;

void Log_Init(void){
	//New header file
	//	char path2[]="header.txt";
	//	retSD=f_open(&SDFile,path2,  FA_WRITE | FA_READ | FA_CREATE_ALWAYS)==FR_OK;
	//	volatile uint8_t header[6];
	//	header[0]=33;
	//	header[1]='D';		//D default (69, 15 bit), pulse width
	//	header[2]=mode;		//spO2 di default
	//	header[3]='D';		//D default (8192), FS
	//	header[4]=frequency;		//1600 Hz di default
	//	header[5]=33;
	//	uint32_t bytesWritten;
	//	retSD=f_write(&SDFile,header,6,&bytesWritten);
	//	f_close(&SDFile);

	//New log file
	//bool retSD;
	char path[]="acq_file.txt";
	//FIXME ExitLowPowerRunMode();
	retSD = f_open(&SDFile,path,  FA_WRITE | FA_READ | FA_CREATE_ALWAYS);
	winter.lp_run=false;

}

void Log_logData(void){
	//
	//	if(logIndex % 256 == 0){
	//		//4 bytes of fake header
	//		little[logIndex]='!';
	//		little[logIndex+1]='!';
	//		little[logIndex+2]='!';
	//		little[logIndex+3]='!';
	//		logIndex+=4;
	//	}
	//
	//	Log_appendData(little,&logIndex);
	//
	//	if(logIndex >= LITTLE_SIZE){
	//		logIndex=0;
	//		HAL_DMA_Start_IT(&hdma_memtomem_dma2_channel1,(uint32_t)((uint32_t*)(little)),
	//				(uint32_t)((uint32_t*)(big + (buffer_section) * LITTLE_SIZE)),LITTLE_SIZE);
	//		++conta_pacchetti;
	////		//FIXME
	////		if(buffer_section + 2 >= BIG_BLOCKS){
	////			ExitLowPowerRunMode();
	////		}
	//		if(buffer_section + 1 >= BIG_BLOCKS){
	//			winter.end_log_buffer=true; // true quando ho copiato nell'ultima parte
	//			buffer_section=0;
	//		}else{
	//			++buffer_section;
	//		}
	//	}
	// **** //

	if(logIndex % 512 == 0){
		//4 bytes of fake header
		little[logIndex]='!';
		little[logIndex + 1]='!';
		little[logIndex + 2]='!';
		little[logIndex + 3]='!';

		logIndex += 4;
	}


	copySampleInBuffer(little,&logIndex);

	f_lseek(&SDFile,f_size(&SDFile));
	UINT bytesWritten;
	retSD = f_write(&SDFile,little + lastCopyIndex, logIndex - lastCopyIndex,&bytesWritten);
	lastCopyIndex = logIndex;
	if(bytesWritten > 0 && retSD == FR_OK){
		f_sync(&SDFile);

	}
}

void copySampleInBuffer(uint8_t* buffer, uint16_t* index){
	//	if(winter.acq_mode==MODE_AXL || winter.acq_mode==MODE_AXL_GYRO){
	//		memcpy(&buffer[*index],winter.acc_sample,6);
	//		*(index)+=6;
	//	}
	//	if(winter.acq_mode==MODE_GYRO || winter.acq_mode==MODE_AXL_GYRO){
	//		memcpy(&buffer[*index],winter.gyro_sample,6);
	//		*(index)+=6;
	//	}

	if(winter.acq_mode == MODE_BIA){
		if(*(index) < LITTLE_SIZE){
			memcpy(&buffer[*index], (uint8_t*)(&(winter.BIA_sample)), 8);
			*index += 8;
		}
		else{
			*(index) = 0;
			lastCopyIndex = 0;
		}
	}
}

//	//FIXME MEM2MEM Tx complete callback if required
//	void MemToMemTxCplt(DMA_HandleTypeDef *dma){
//		if(winter.end_log_buffer){
//			//FIXME ExitLowPowerRunMode();
//			f_lseek(&SDFile,f_size(&SDFile));
//			UINT bytesWritten;
//			retSD=f_write(&SDFile,big,BIG_SIZE,&bytesWritten);
//			if(bytesWritten > 0 && retSD == FR_OK){
//				f_sync(&SDFile);
//			}
//			winter.end_log_buffer= false;
//			winter.lp_run=false;
//		}
//	}


