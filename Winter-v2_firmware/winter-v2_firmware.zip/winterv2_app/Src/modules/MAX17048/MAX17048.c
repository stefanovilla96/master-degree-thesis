/**
 * @file    IO.c
 * @author  Daniele Comotti - daniele.comotti@221e.com
 * @version V1.0
 * @date    04 April, 2018
 * @brief   Implementation file for MAX17048
 * @details Edit this file at your own risk
 * 221e SRL, www.221e.com
 */

/* Includes */
#include "MAX17048/MAX17048.h"
#include "stm32l4xx_hal.h"

extern I2C_HandleTypeDef hi2c3;

uint16_t MAX17048_ADDR = 0x6C;

/**
 * @brief  Writes one byte to the  MAX17048.
 * @param  pcBuffer : pointer to the buffer  containing the data to be written to the MAX17048.
 * @param  cWriteAddr : address of the register in which the data will be written
 * @retval None
 */
bool MAX17048I2CByteWrite(uint8_t RegName, uint8_t* RegValue){

	uint8_t writedReg[3] = {RegName, RegValue[0], RegValue[1]};

	return HAL_I2C_Master_Transmit(&hi2c3, MAX17048_ADDR, writedReg, 3, 100) == HAL_OK;
}

/**
 * @brief  Reads a block of data from the MAX17048.
 * @param  cAddr  : slave address
 * @param  pcBuffer : pointer to the buffer that receives the data read from the MAX17048.
 * @param  cReadAddr : MAX17048's internal address to read from.
 * @param  nNumByteToRead : number of bytes to read from the MAX17048DLH ( NumByteToRead >1  only for the Magnetometer readinf).
 * @retval None
 */
bool MAX17048I2CBufferRead(uint8_t RegName, uint8_t* readByte){
	bool res = true;
	res &= HAL_I2C_Master_Transmit(&hi2c3, MAX17048_ADDR, &RegName, 1, 100) == HAL_OK;
	res &= HAL_I2C_Master_Receive(&hi2c3, MAX17048_ADDR, readByte, 2, 100) == HAL_OK;
	return res;
}

uint16_t MAX17048_ReadVoltage(void){
	uint16_t battery_Voltage = 0;
	uint8_t bat_temp[2] = {0, 0};

	float my_voltage = 0.0f;

	MAX17048I2CBufferRead(MAX17048_REG_VCELL, bat_temp);
	battery_Voltage = (((uint16_t) bat_temp[0]) << 8) + ((uint16_t) bat_temp[1]);
	//Value in mV
	my_voltage = ((battery_Voltage / 16) * 1.25);

	return (uint16_t) my_voltage;
}

uint8_t MAX17048_ReadSOC(void){
	uint8_t soc_temp[2] = {0, 0};

	MAX17048I2CBufferRead(MAX17048_REG_SOC, soc_temp);

	if((soc_temp[0] == 0 && soc_temp[1] == 0) || soc_temp[0] > 110){
		//If the gas gauge is stuck, reset the IC
		uint8_t b[2];
		b[0] = 0x54;
		b[1] = 0;
		MAX17048I2CByteWrite(MAX17048_REG_CMD, b);
	}

	return soc_temp[0];
}
