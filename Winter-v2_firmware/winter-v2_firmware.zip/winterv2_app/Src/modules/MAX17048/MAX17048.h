/**
 * @file    IO.c
 * @author  Daniele Comotti - daniele.comotti@221e.com
 * @version V1.0
 * @date    04 April, 2018
 * @brief   Header file for MAX17048
 * @details Edit this file at your own risk
 * 221e SRL, www.221e.com
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAX17048_H
#define __MAX17048_H

#include "stdbool.h"
#include "stdint.h"

//RTC time registers
#define MAX17048_REG_VCELL	0x02 //READ - VCELL measurement between VDD and GND,#define MAX17048_REG_SOC	0x04 //READ - SOC measurement#define MAX17048_REG_MODE	0x06 //WRITE - enable quick start, sleep and hibernate status#define MAX17048_REG_VERSION	0x08 //READ - production version of the IC#define MAX17048_REG_HIBRT	0x0A //RW - config hibernate and activation status#define MAX17048_REG_CONFIG	0x0C#define MAX17048_REG_VALRT	0x14#define MAX17048_REG_CRATE	0x16#define MAX17048_REG_VRES_ID	0x18#define MAX17048_REG_STAT	0x1A#define MAX17048_REG_CMD	0xFE

/**
 * @brief  Accelerometer/Magnetometer Functional state. Used to enable or disable a specific option.
 */
typedef enum {
	MAX17048_DISABLE = 0, MAX17048_ENABLE = !MAX17048_DISABLE
} MAX17048FunctionalState;

bool MAX17048I2CByteWrite(uint8_t RegName, uint8_t* RegValue);
bool MAX17048I2CBufferRead(uint8_t RegName, uint8_t* readByte);
uint16_t MAX17048_ReadVoltage(void);
uint8_t MAX17048_ReadSOC(void);

#endif /* __MAX17048_H */
