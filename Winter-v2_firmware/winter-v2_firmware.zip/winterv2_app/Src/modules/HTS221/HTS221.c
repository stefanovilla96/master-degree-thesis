/*
 * RTC.c
 *
 *  Created on: Feb 9, 2015
 *      Author: Daniele Comotti - daniele.comotti@unibg.i
 *		University of Bergamo - MicroLab
 */

#include "HTS221.h"
#include "stm32l4xx_hal.h"
#include "main.h"

uint16_t HTS221_ADDR = 0x00BE;

float HTS221_T_slope = 0;
float HTS221_H_slope = 0;
float HTS221_T_offset = 0;
float HTS221_H_offset = 0;

/*******************************************************************************
 * @brief  Read the specified register from the RTC.
 * @param  RegName: specifies the RTC register to be read.
 * @retval RTC register value.
 *******************************************************************************/
bool HTS221_ReadReg(uint8_t RegName, uint8_t* readByte) {
	return I2CRead(HTS221_ADDR, RegName, readByte, 1, I2C_HUM);
}

/*******************************************************************************
 * @brief  Write to the specified register of the RTC.
 * @param  RegName: specifies the RTC register to be written.
 * @param  RegValue: value to be written to RTC register.
 * @retval boolean
 *******************************************************************************/
bool HTS221_WriteReg(uint8_t RegName, uint8_t RegValue) {
	uint8_t temp[2];
	temp[0] = RegName;
	temp[1] = RegValue;
	return I2CWrite(HTS221_ADDR, temp, 2, I2C_HUM);
}

void HTS221_Config(void) {
	uint8_t temp;
	temp = 0x3F;
	HTS221_WriteReg(HTS221_REG_AV_CONF, temp);

	HTS221_ReadReg(HTS221_REG_AV_CONF, &temp);

	temp = 0x87;
	HTS221_WriteReg(HTS221_REG_CTRL1, temp);
	HTS221_ReadReg(HTS221_REG_CTRL1, &temp);

	uint16_t T0_out, T1_out;
	int16_t T0_outS, T1_outS;
	float T0_degC, T1_degC;
	//-------------Temperature------------
	HTS221_ReadReg(HTS221_REG_T0_OUT_L, &temp);
	T0_out = temp;
	HTS221_ReadReg(HTS221_REG_T0_OUT_H, &temp);
	T0_out |= (uint16_t) (temp << 8);
	T0_outS = *((int16_t*) (&T0_out));

	HTS221_ReadReg(HTS221_REG_T1_OUT_L, &temp);
	T1_out = temp;
	HTS221_ReadReg(HTS221_REG_T1_OUT_H, &temp);
	T1_out |= (uint16_t) (temp << 8);
	T1_outS = *((int16_t*) (&T1_out));

	HTS221_ReadReg(HTS221_REG_T1_T0_msb, &temp);
	T0_degC = ((((uint16_t) temp) & 0x03) << 8);
	T1_degC = ((((uint16_t) temp) & 0x0C) << 6);

	HTS221_ReadReg(HTS221_REG_T0_degC_x8, &temp);
	T0_degC += temp;
	T0_degC /= 8;

	HTS221_ReadReg(HTS221_REG_T1_degC_x8, &temp);
	T1_degC += temp;
	T1_degC /= 8;

	HTS221_T_slope = (T1_degC - T0_degC) / (T1_outS - T0_outS);

	HTS221_T_offset = T0_degC - T0_outS * HTS221_T_slope;

	//-------Humidity-----------
	HTS221_ReadReg(HTS221_REG_H0_T0_OUT_L, &temp);
	T0_out = temp;
	HTS221_ReadReg(HTS221_REG_H0_T0_OUT_H, &temp);
	T0_out |= (uint16_t) (temp << 8);
	T0_outS = *((int16_t*) (&T0_out));

	HTS221_ReadReg(HTS221_REG_H1_T0_OUT_L, &temp);
	T1_out = temp;
	HTS221_ReadReg(HTS221_REG_H1_T0_OUT_H, &temp);
	T1_out |= (uint16_t) (temp << 8);
	T1_outS = *((int16_t*) (&T1_out));

	HTS221_ReadReg(HTS221_REG_H0_rH_x2, &temp);
	T0_degC = temp;
	T0_degC /= 2;

	HTS221_ReadReg(HTS221_REG_H1_rH_x2, &temp);
	T1_degC = temp;
	T1_degC /= 2;

	HTS221_H_slope = (T1_degC - T0_degC) / (T1_outS - T0_outS);

	HTS221_H_offset = T0_degC - T0_outS * HTS221_T_slope;
}

float HTS221_readOut_Temperature(void) {
	uint8_t temp[2];

	HTS221_ReadReg(HTS221_REG_TEMP_OUT_L, temp);
	HTS221_ReadReg(HTS221_REG_TEMP_OUT_H, temp + 1);

	int16_t tempData = (uint16_t) temp[0] | ((uint16_t) temp[1] << 8);

	float result;
	result = tempData * HTS221_T_slope + HTS221_T_offset;

	return result;
}

float HTS221_readOut_Humidity(void) {
	uint8_t temp[2];

	HTS221_ReadReg(HTS221_REG_HUM_OUT_L, temp);
	HTS221_ReadReg(HTS221_REG_HUM_OUT_H, temp + 1);

	int16_t tempData = (uint16_t) temp[0] | ((uint16_t) temp[1] << 8);

	float result;
	result = tempData * HTS221_H_slope + HTS221_H_offset;

	return result;
}

bool HTS221_Check_Who_Am_I(void) {
	uint8_t temp;
	HTS221_ReadReg(HTS221_REG_WHO_AM_I, &temp);
	return temp == HTS221_WHO_AM_I_CONTENT;

}
