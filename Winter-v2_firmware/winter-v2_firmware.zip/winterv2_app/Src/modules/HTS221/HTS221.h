/*
 * RTC.h
 *
 *  Created on: Feb 9, 2015
 *      Author: Daniele Comotti - daniele.comotti@unibg.i
 *		University of Bergamo - MicroLab
 */

#ifndef HTS221_H_
#define HTS221_H_

#include "time.h"
#include "stdint.h"
#include "stdbool.h"

#define HTS221_REG_WHO_AM_I	0x0F

#define HTS221_REG_AV_CONF	0x10

#define HTS221_REG_CTRL1	0x20

#define HTS221_REG_CTRL2	0x21

#define HTS221_REG_CTRL3	0x22

#define HTS221_REG_STATUS	0x27

#define HTS221_REG_HUM_OUT_L	0x28

#define HTS221_REG_HUM_OUT_H	0x29

#define HTS221_REG_TEMP_OUT_L	0x2A

#define HTS221_REG_TEMP_OUT_H	0x2B

#define HTS221_REG_H0_rH_x2	0x30

#define HTS221_REG_H1_rH_x2	0x31

#define HTS221_REG_T0_degC_x8	0x32

#define HTS221_REG_T1_degC_x8	0x33

#define HTS221_REG_T1_T0_msb	0x35

#define HTS221_REG_H0_T0_OUT_L	0x36

#define HTS221_REG_H0_T0_OUT_H	0x37

#define HTS221_REG_H1_T0_OUT_L	0x3A

#define HTS221_REG_H1_T0_OUT_H	0x3B

#define HTS221_REG_T0_OUT_L	0x3C

#define HTS221_REG_T0_OUT_H	0x3D

#define HTS221_REG_T1_OUT_L	0x3E

#define HTS221_REG_T1_OUT_H	0x3F

#define HTS221_WHO_AM_I_CONTENT	0xBC

void HTS221_Config(void);

bool HTS221_ReadReg(uint8_t RegName, uint8_t* readByte);

bool HTS221_WriteReg(uint8_t RegName, uint8_t RegValue);

float HTS221_readOut_Humidity(void);

float HTS221_readOut_Temperature(void);

bool HTS221_Check_Who_Am_I(void);

#endif /* RTC_H_ */
