/*
 * AD5940Main.h
 *
 *  Created on: 13 lug 2020
 *      Author: Stefano Villa
 */

#ifndef AD5940MAIN_H_
#define AD5940MAIN_H_

#include "ad5940.h"
#include "stdbool.h"

#define APPBUFF_SIZE 512

int32_t BIAShowResult(uint32_t *pData, uint32_t DataCount);

int32_t AD5940PlatformCfg(void);

void AD5940BIAStructInit(void);


#endif /* AD5940MAIN_H_ */
