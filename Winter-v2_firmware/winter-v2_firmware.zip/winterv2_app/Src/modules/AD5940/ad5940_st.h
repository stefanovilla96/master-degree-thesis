/*
 * NUCLEOF411Port.h
 *
 *  Created on: 17 set 2020
 *      Author: Stefano Villa
 */


#ifndef AD5940_ST_H_
#define AD5940_ST_H_

#include "stdint.h"
#include <stdbool.h>

#define SpiHandle hspi2

void AD5940_ReadWriteNBytes(unsigned char *pSendBuffer,unsigned char *pRecvBuff,unsigned long length);
void AD5940_CsClr(void);
void AD5940_CsSet(void);
void AD5940_RstSet(void);
void AD5940_RstClr(void);
void AD5940_Delay10us(uint32_t time);
uint32_t AD5940_GetMCUIntFlag(void);
uint32_t AD5940_ClrMCUIntFlag(void);
uint32_t AD5940_MCUResourceInit(void *pCfg);
bool checkAD5940Communication();

#endif /* MODULES_NUCLEOF411PORT_H_ */
