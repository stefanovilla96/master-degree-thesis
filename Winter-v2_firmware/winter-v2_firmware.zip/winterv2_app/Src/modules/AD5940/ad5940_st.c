/**  
 * @file       NUCLEOF411Port.c
 * @brief      ST NUCLEOF411 board port file.
 * @version    V0.2.0
 * @author     ADI
 * @date       March 2019
 * @par Revision History:
 * 
 * Copyright (c) 2017-2019 Analog Devices, Inc. All Rights Reserved.
 * 
 * This software is proprietary to Analog Devices, Inc. and its licensors.
 * By using this software you agree to the terms of the associated
 * Analog Devices Software License Agreement.
 **/
#include <AD5940/ad5940_st.h>
#include "ad5940.h"
#include "stdio.h"
#include "stm32l4xx_hal.h"
#include "main.h"
/* Definition for STM32 SPI clock resources */
/*
 #define AD5940SPI                          SPI1
 #define AD5940_CLK_ENABLE()                __HAL_RCC_SPI1_CLK_ENABLE()
 #define AD5940_SCK_GPIO_CLK_ENABLE()       __HAL_RCC_GPIOA_CLK_ENABLE()
 #define AD5940_MISO_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE()
 #define AD5940_MOSI_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE()
 #define AD5940_CS_GPIO_CLK_ENABLE()        __HAL_RCC_GPIOB_CLK_ENABLE()
 #define AD5940_RST_GPIO_CLK_ENABLE()       __HAL_RCC_GPIOB_CLK_ENABLE()
 #define AD5940_GP0INT_GPIO_CLK_ENABLE()    __HAL_RCC_GPIOA_CLK_ENABLE()

 #define AD5940SPI_FORCE_RESET()               __HAL_RCC_SPI1_FORCE_RESET()
 #define AD5940SPI_RELEASE_RESET()             __HAL_RCC_SPI1_RELEASE_RESET()
 */

/* Definition for AD5940 Pins */
/*
 #define AD5940_SCK_PIN                     GPIO_PIN_5
 #define AD5940_SCK_GPIO_PORT               GPIOA
 #define AD5940_SCK_AF                      GPIO_AF5_SPI1
 #define AD5940_MISO_PIN                    GPIO_PIN_6
 #define AD5940_MISO_GPIO_PORT              GPIOA
 #define AD5940_MISO_AF                     GPIO_AF5_SPI1
 #define AD5940_MOSI_PIN                    GPIO_PIN_7
 #define AD5940_MOSI_GPIO_PORT              GPIOA
 #define AD5940_MOSI_AF                     GPIO_AF5_SPI1

 #define AD5940_CS_PIN                      GPIO_PIN_6
 #define AD5940_CS_GPIO_PORT                GPIOB

 #define AD5940_RST_PIN                     GPIO_PIN_0   //A3
 #define AD5940_RST_GPIO_PORT               GPIOB

 #define AD5940_GP0INT_PIN                  GPIO_PIN_10   //A3
 #define AD5940_GP0INT_GPIO_PORT            GPIOA
 #define AD5940_GP0INT_IRQn                 EXTI15_10_IRQn
 */
SPI_HandleTypeDef SpiHandle;

#define SYSTICK_MAXCOUNT ((1L<<24)-1) /* we use Systick to complete function Delay10uS(). This value only applies to NUCLEOF411 board. */
#define SYSTICK_CLKFREQ   100000000L  /* Systick clock frequency in Hz. This only appies to NUCLEOF411 board */
volatile uint8_t ucInterrupted=0; /* Flag to indicate interrupt occurred */

/**
 @brief Using SPI to transmit N bytes and return the received bytes. This function targets to
 provide a more efficent way to transmit/receive data.
 @param pSendBuffer :{0 - 0xFFFFFFFF}
 - Pointer to the data to be sent.
 @param pRecvBuff :{0 - 0xFFFFFFFF}
 - Pointer to the buffer used to store received data.
 @param length :{0 - 0xFFFFFFFF}
 - Data length in SendBuffer.
 @return None.
 **/
void AD5940_ReadWriteNBytes(unsigned char *pSendBuffer, unsigned char *pRecvBuff, unsigned long length){
	HAL_SPI_TransmitReceive(&SpiHandle,pSendBuffer,pRecvBuff,length,(uint32_t)-1);
}

void AD5940_CsClr(void){
	HAL_GPIO_WritePin(SPI2_CS_GPIO_Port,SPI2_CS_Pin,GPIO_PIN_RESET);
}

void AD5940_CsSet(void){
	HAL_GPIO_WritePin(SPI2_CS_GPIO_Port,SPI2_CS_Pin,GPIO_PIN_SET);
}

void AD5940_RstSet(void){
	HAL_GPIO_WritePin(BIOZ_RESET_GPIO_Port,BIOZ_RESET_Pin,GPIO_PIN_SET);
}

void AD5940_RstClr(void){
	HAL_GPIO_WritePin(BIOZ_RESET_GPIO_Port,BIOZ_RESET_Pin,GPIO_PIN_RESET);

}

void AD5940_Delay10us(uint32_t time){
	time/=100;
	if(time == 0)
		time=1;
	HAL_Delay(time);
}

uint32_t AD5940_GetMCUIntFlag(void){
	return ucInterrupted;
}

uint32_t AD5940_ClrMCUIntFlag(void){
	ucInterrupted=0;
	return 1;
}

uint32_t AD5940_MCUResourceInit(void *pCfg){
	AD5940_CsSet();
	AD5940_RstSet();

	return 0;
}

bool checkAD5940Communication(){


	HAL_GPIO_WritePin(SPI2_CS_GPIO_Port, SPI2_CS_Pin, GPIO_PIN_RESET);
	uint8_t first_step_buffer[3] = {0x20, 0x04, 0x04};
	HAL_SPI_Transmit(&hspi2, first_step_buffer, 3, 100);
	HAL_GPIO_WritePin(SPI2_CS_GPIO_Port, SPI2_CS_Pin, GPIO_PIN_SET);

	//FIXME ??
	HAL_Delay(100);

	HAL_GPIO_WritePin(SPI2_CS_GPIO_Port, SPI2_CS_Pin, GPIO_PIN_RESET);
	uint8_t cmd[2] = {0x6D, 0x00};
	HAL_SPI_Transmit(&hspi2, cmd, 2, 100);
	uint8_t read_register_value[2] = {0x00, 0x00};
	HAL_SPI_Receive(&hspi2, read_register_value, 2, 100);
	HAL_GPIO_WritePin(SPI2_CS_GPIO_Port, SPI2_CS_Pin, GPIO_PIN_SET);

	return (read_register_value[0] == 0x55 && read_register_value[1] == 0x2) ? true : false;
}

