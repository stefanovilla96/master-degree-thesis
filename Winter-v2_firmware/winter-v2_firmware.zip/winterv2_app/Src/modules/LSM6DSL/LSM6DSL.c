/**
 * @file    LSM6DSL.c
 * @author  Andrea Pedrana - andrea.pedrana@unibg.it
 * @version 1.0
 * @date    2019/06/11
 * @brief   Header of the LSM6DSL driver
 * @details For SPI 3-wires mode, set "Half Duplex Master" in STM32Cube MX. SPI_1LINE_TX(&hspix) and SPI_1LINE_RX(&hspix) calls
 * are used to alternate the transmission direction (needed only when reading something)
 * Universit� degli studi di Bergamo, Microelectronics Laboratory
 */

#include "LSM6DSL.h"
#include "stm32l4xx_hal.h"
#include "main.h"
#include "string.h"

#ifdef LSM6DSL_SPI

extern SPI_HandleTypeDef hspi_ag;

#else

extern I2C_HandleTypeDef hi2c_ag;

#endif

LSM6DSL_Init_TypeDef ag_init;

// Definition of static SPI/I2C read/write functions
#ifdef LSM6DSL_SPI

static bool LSM6DSL_SPI_Write(uint8_t RegName, uint8_t* RegValue, uint8_t numberOfBytes);

static bool LSM6DSL_SPI_Read(uint8_t RegName, uint8_t* readByte, uint8_t numberOfBytes);

#else

static bool LSM6DSL_I2C_Write(uint8_t RegName, uint8_t* RegValue, uint8_t numberOfBytes);

static bool LSM6DSL_I2C_Read(uint8_t RegName, uint8_t* readByte, uint8_t numberOfBytes);

#endif

/**
 * Write LSM6DSL register(s)
 */
bool LSM6DSL_WriteReg(uint8_t regName, uint8_t* regValue, uint8_t numberOfBytes){
#ifdef LSM6DSL_SPI
	return LSM6DSL_SPI_Write(regName,regValue,numberOfBytes);
#else
	return LSM6DSL_I2C_Write(regName,regValue,numberOfBytes);
#endif
}

/**
 * Read LSM6DSL register(s)
 */
bool LSM6DSL_ReadReg(uint8_t regName, uint8_t* readByte, uint8_t numberOfBytes){
#ifdef LSM6DSL_SPI
	return LSM6DSL_SPI_Read(regName,readByte,numberOfBytes);
#else
	return LSM6DSL_I2C_Read(regName,readByte,numberOfBytes);
#endif
}

#ifdef LSM6DSL_SPI
/**
 * SPI write
 */
static bool LSM6DSL_SPI_Write(uint8_t RegName, uint8_t* RegValue, uint8_t numberOfBytes){
	bool result= true;
	//Tight low CS
	HAL_GPIO_WritePin(CS_AG_GPIO_Port,CS_AG_Pin,GPIO_PIN_RESET);
	//Mask in order to have 0 as MSb of the address byte
	RegName=RegName & 0x7F;

	uint8_t tx_buffer[numberOfBytes + 1];
	uint8_t i;
	tx_buffer[0]=RegName;
	for(i=0;i < numberOfBytes;i++)
		tx_buffer[i + 1]=RegValue[i];

	result&=HAL_SPI_Transmit(&hspi_ag,tx_buffer,numberOfBytes + 1,100) == HAL_OK;

	//Tight low CS
	HAL_GPIO_WritePin(CS_AG_GPIO_Port,CS_AG_Pin,GPIO_PIN_SET);

	return result;
}

/**
 * SPI read
 */
static bool LSM6DSL_SPI_Read(uint8_t RegName, uint8_t* readByte, uint8_t numberOfBytes){
	bool result= true;
	/// Tight low CS
	HAL_GPIO_WritePin(CS_AG_GPIO_Port,CS_AG_Pin,GPIO_PIN_RESET);
	/// Mask in order to have 1 as MSb of the address byte
	RegName|=0x80;

	result&=HAL_SPI_Transmit(&hspi_ag,&RegName,1,100) == HAL_OK;

	/// Set unidirectional line TX
	if(ag_init.comm_interface == LSM6DSL_SPI_3WIRES){
		SPI_1LINE_RX(&hspi_ag);
	}

	result&=HAL_SPI_Receive(&hspi_ag,readByte,numberOfBytes,100) == HAL_OK;

	/// Tight low CS
	HAL_GPIO_WritePin(CS_AG_GPIO_Port,CS_AG_Pin,GPIO_PIN_SET);

	/// Set again unidirectional TX
	if(ag_init.comm_interface == LSM6DSL_SPI_3WIRES){
		SPI_1LINE_TX(&hspi_ag);
	}

	return result;
}

#else

/**
 * I2C write
 */
static bool LSM6DSL_I2C_Write(uint8_t RegName, uint8_t* RegValue, uint8_t numberOfBytes){
	bool result= true;

	uint8_t tx_buffer[numberOfBytes + 1];
	uint8_t i;
	tx_buffer[0]=RegName;
	for(i=0;i < numberOfBytes;i++)
	tx_buffer[i + 1]=RegValue[i];

	result&=HAL_I2C_Master_Transmit(&hi2c_ag,LSM6DSL_I2C_ADDRESS,tx_buffer,numberOfBytes + 1,100) == HAL_OK;

	return result;
}

/**
 * I2C read
 */
static bool LSM6DSL_I2C_Read(uint8_t RegName, uint8_t* readByte, uint8_t numberOfBytes){
	bool result= true;

	result&=HAL_I2C_Master_Transmit(&hi2c_ag,LSM6DSL_I2C_ADDRESS,&RegName,1,100) == HAL_OK;

	result&=HAL_I2C_Master_Receive(&hi2c_ag,LSM6DSL_I2C_ADDRESS,readByte,numberOfBytes,100) == HAL_OK;

	return result;
}

#endif

/**
 * Configuration of LSM6DSL operation
 */
bool LSM6DSL_Config(LSM6DSL_Init_TypeDef initStruct){
	bool result;
	//Store configuration parameters
	memcpy((uint8_t*)&ag_init,(uint8_t*)&initStruct,sizeof(LSM6DSL_Init_TypeDef));

	uint8_t temp;

	if(ag_init.comm_interface == LSM6DSL_SPI_3WIRES){
		/// Set 1 direction TX mode
		SPI_1LINE_TX(&hspi_ag);

		/// Write CTRL3_C register to set SPI 3-wire interface
		/// Value: 0x0C (register autoincrement enabled, SPI 3-wire interface enabled)
		temp=LSM6DSL_REG_CTRL3_C_SPI3WIRE_ENABLE
		;
		LSM6DSL_WriteReg(LSM6DSL_REG_CTRL3_C,&temp,1);
	}

	/// CTRL1_XL
	temp=ag_init.axl_odr | ag_init.axl_fs | ag_init.axl_lpf | ag_init.axl_bw0;
	LSM6DSL_WriteReg(LSM6DSL_REG_CTRL1_XL,&temp,1);

	/// CTRL2_G
	temp=ag_init.gyro_odr | ag_init.gyro_fs;
	LSM6DSL_WriteReg(LSM6DSL_REG_CTRL2_G,&temp,1);

	/// CTRL3_C
	temp=ag_init.bdu;
	if(ag_init.comm_interface == LSM6DSL_SPI_3WIRES){
		temp|= LSM6DSL_REG_CTRL3_C_SPI3WIRE_ENABLE
		;
	}
	LSM6DSL_WriteReg(LSM6DSL_REG_CTRL3_C,&temp,1);

	/// Read back configuration registers
	uint8_t check[3];
	LSM6DSL_ReadReg(LSM6DSL_REG_CTRL1_XL,check,3);

	/// Default mode High-performance for both accelerometer and gyroscope
	if(ag_init.comm_interface == LSM6DSL_SPI_3WIRES){
		temp=LSM6DSL_REG_CTRL3_C_SPI3WIRE_ENABLE
		;
	}else{
		temp=0;
	}
	result=((check[0] == (ag_init.axl_odr | ag_init.axl_fs | ag_init.axl_lpf | ag_init.axl_bw0))
			&& (check[1] == (ag_init.gyro_odr | ag_init.gyro_fs)) && (check[2] == (ag_init.bdu | temp)));
	return result;
}

/**
 * Accelerometer power-down
 */
void LSM6DSL_axl_power_down(bool arg){
	uint8_t temp;
	LSM6DSL_ReadReg(LSM6DSL_REG_CTRL1_XL,&temp,1);
	if(arg && (temp & 0xF0)){
		//AXL is configured
		temp&=0x0F;
		LSM6DSL_WriteReg(LSM6DSL_REG_CTRL1_XL,&temp,1);
	}else{
		if(!arg && !((temp & 0xF0))){
			//AXL is in power down
			temp|=ag_init.axl_odr;
			LSM6DSL_WriteReg(LSM6DSL_REG_CTRL1_XL,&temp,1);
		}
	}
}

/**
 * Gyroscope power-down
 */
void LSM6DSL_gyro_power_down(bool arg){
	uint8_t temp;
	LSM6DSL_ReadReg(LSM6DSL_REG_CTRL2_G,&temp,1);
	if(arg && (temp & 0xF0)){
		//Gyro is configured
		temp&=0x0F;
		LSM6DSL_WriteReg(LSM6DSL_REG_CTRL2_G,&temp,1);
	}else{
		if(!arg && !((temp & 0xF0))){
			//Gyro is in power down
			temp|=ag_init.gyro_odr;
			LSM6DSL_WriteReg(LSM6DSL_REG_CTRL2_G,&temp,1);
		}
	}
}

/**
 * Read accelerometer samples
 */
void LSM6DSL_read_axl(float* axl, uint16_t *axlRaw){
	uint8_t temp[6];
	float axl_sensitivity=0;
	uint8_t i;

	LSM6DSL_ReadReg(LSM6DSL_REG_OUTX_L_XL,temp,6);

	//---Read out axl data---
	switch(ag_init.axl_fs){
		case LSM6DSL_REG_CTRL1_FS_2g:
			axl_sensitivity= LSM6DSL_AXL_SENSITIVITY_2g;
			break;
		case LSM6DSL_REG_CTRL1_FS_16g:
			axl_sensitivity= LSM6DSL_AXL_SENSITIVITY_16g;
			break;
		case LSM6DSL_REG_CTRL1_FS_4g:
			axl_sensitivity= LSM6DSL_AXL_SENSITIVITY_4g;
			break;
		case LSM6DSL_REG_CTRL1_FS_8g:
			axl_sensitivity= LSM6DSL_AXL_SENSITIVITY_8g;
			break;
		default:
			axl_sensitivity= LSM6DSL_AXL_SENSITIVITY_2g;
			break;
	}

	for(i=0;i < 3;i++){
		uint16_t temp_data=temp[i * 2];
		temp_data+=(((uint16_t)temp[i * 2 + 1]) << 8);
		axlRaw[i]=temp_data;
		axl[i]=(float)((int16_t)(*((int16_t*)&temp_data)));
		axl[i]*=axl_sensitivity;
	}
}

/**
 * Read gyroscope samples
 */
void LSM6DSL_read_gyro(float* gyro, uint16_t* gyroRaw){
	uint8_t temp[6];
	float gyro_sensitivity=0;
	uint8_t i;

	LSM6DSL_ReadReg(LSM6DSL_REG_OUTX_L_G,temp,6);

	//---Read out gyro data---
	switch(ag_init.gyro_fs){
		case LSM6DSL_REG_CTRL2_G_FS_250dps:
			gyro_sensitivity= LSM6DSL_GYRO_SENSITIVITY_250dps;
			break;
		case LSM6DSL_REG_CTRL2_G_FS_500dps:
			gyro_sensitivity= LSM6DSL_GYRO_SENSITIVITY_500dps;
			break;
		case LSM6DSL_REG_CTRL2_G_FS_1000dps:
			gyro_sensitivity= LSM6DSL_GYRO_SENSITIVITY_1000dps;
			break;
		case LSM6DSL_REG_CTRL2_G_FS_2000dps:
			gyro_sensitivity= LSM6DSL_GYRO_SENSITIVITY_2000dps;
			break;
		default:
			gyro_sensitivity= LSM6DSL_GYRO_SENSITIVITY_2000dps;
			break;
	}
	gyro_sensitivity/=1000;
	for(i=0;i < 3;i++){
		uint16_t temp_data=temp[i * 2];
		temp_data+=(((uint16_t)temp[i * 2 + 1]) << 8);
		gyroRaw[i]=temp_data;
		gyro[i]=(float)((int16_t)(*((int16_t*)&temp_data)));
		gyro[i]*=gyro_sensitivity;
	}
}

/**
 * Read accelerometer and gyroscope samples
 */
void LSM6DSL_read_axl_gyro(float* axl, uint16_t *axlRaw, float* gyro, uint16_t* gyroRaw){
	uint8_t temp[12];
	float gyro_sensitivity=0;
	float axl_sensitivity=0;
	uint8_t i;

	LSM6DSL_ReadReg(LSM6DSL_REG_OUTX_L_G,temp,12);

	//---Read out gyro data---
	switch(ag_init.gyro_fs){
		case LSM6DSL_REG_CTRL2_G_FS_250dps:
			gyro_sensitivity= LSM6DSL_GYRO_SENSITIVITY_250dps;
			break;
		case LSM6DSL_REG_CTRL2_G_FS_500dps:
			gyro_sensitivity= LSM6DSL_GYRO_SENSITIVITY_500dps;
			break;
		case LSM6DSL_REG_CTRL2_G_FS_1000dps:
			gyro_sensitivity= LSM6DSL_GYRO_SENSITIVITY_1000dps;
			break;
		case LSM6DSL_REG_CTRL2_G_FS_2000dps:
			gyro_sensitivity= LSM6DSL_GYRO_SENSITIVITY_2000dps;
			break;
		default:
			gyro_sensitivity= LSM6DSL_GYRO_SENSITIVITY_2000dps;
			break;
	}
	gyro_sensitivity/=1000;
	for(i=0;i < 3;i++){
		uint16_t temp_data=temp[i * 2];
		temp_data+=(((uint16_t)temp[i * 2 + 1]) << 8);
		gyroRaw[i]=temp_data;
		gyro[i]=(float)((int16_t)(*((int16_t*)&temp_data)));
		gyro[i]*=gyro_sensitivity;
	}

	//---Read out axl data---
	switch(ag_init.axl_fs){
		case LSM6DSL_REG_CTRL1_FS_2g:
			axl_sensitivity= LSM6DSL_AXL_SENSITIVITY_2g;
			break;
		case LSM6DSL_REG_CTRL1_FS_16g:
			axl_sensitivity= LSM6DSL_AXL_SENSITIVITY_16g;
			break;
		case LSM6DSL_REG_CTRL1_FS_4g:
			axl_sensitivity= LSM6DSL_AXL_SENSITIVITY_4g;
			break;
		case LSM6DSL_REG_CTRL1_FS_8g:
			axl_sensitivity= LSM6DSL_AXL_SENSITIVITY_8g;
			break;
		default:
			axl_sensitivity= LSM6DSL_AXL_SENSITIVITY_2g;
			break;
	}

	for(i=0;i < 3;i++){
		uint16_t temp_data=temp[i * 2 + 6];
		temp_data+=(((uint16_t)temp[i * 2 + 7]) << 8);
		axlRaw[i]=temp_data;
		axl[i]=(float)((int16_t)(*((int16_t*)&temp_data)));
		axl[i]*=axl_sensitivity;
	}
}

/**
 * Check WHO_AM_I register
 */
bool LSM6DSL_check_WhoAmI(void){
	uint8_t temp;
	LSM6DSL_ReadReg(LSM6DSL_REG_WHO_AM_I,&temp,1);
	return temp == LSM6DSL_WHO_AM_I_CONTENT;
}

/**
 * Set the accelerometer full-scale
 */
bool LSM6DSL_setAxlFS(LSM6DSL_REG_CTRL1_FS fs){
	bool result=true;
	// Check if desired full scale value is valid
	if(fs == LSM6DSL_REG_CTRL1_FS_2g || fs == LSM6DSL_REG_CTRL1_FS_16g || fs == LSM6DSL_REG_CTRL1_FS_4g
			|| fs == LSM6DSL_REG_CTRL1_FS_8g){
		uint8_t temp;
		// Read CTRL1_XL register
		result&=LSM6DSL_ReadReg(LSM6DSL_REG_CTRL1_XL,&temp,1);
		if(result){
			// Mask full scale and update
			temp=(temp & 0xF3) | fs;
			result&=LSM6DSL_WriteReg(LSM6DSL_REG_CTRL1_XL,&temp,1);
			if(result){
				ag_init.axl_fs=fs;
				return true;
			}
		}
	}
	return false;
}

/**
 * Set the gyroscope full-scale
 */
bool LSM6DSL_setGyroFS(LSM6DSL_REG_CTRL2_G_FS fs){
	bool result=true;
	// Check if desired full scale value is valid
	if(fs == LSM6DSL_REG_CTRL2_G_FS_250dps || fs == LSM6DSL_REG_CTRL2_G_FS_500dps || fs == LSM6DSL_REG_CTRL2_G_FS_1000dps
			|| fs == LSM6DSL_REG_CTRL2_G_FS_2000dps){
		uint8_t temp;
		// Read CTRL2_G register
		result&=LSM6DSL_ReadReg(LSM6DSL_REG_CTRL2_G,&temp,1);
		if(result){
			// Mask full scale and update
			temp=(temp & 0xF3) | fs;
			result&=LSM6DSL_WriteReg(LSM6DSL_REG_CTRL2_G,&temp,1);
			if(result){
				ag_init.gyro_fs=fs;
				return true;
			}
		}
	}
	return false;
}
