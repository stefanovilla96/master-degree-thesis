/**
 * @file    LSM6DSL.h
 * @author  Andrea Pedrana - andrea.pedrana@unibg.it
 * @version 1.0
 * @date    2019/06/11
 * @brief   Header of the LSM6DSL driver
 * Universit� degli studi di Bergamo, Microelectronics Laboratory
 */

#ifndef LSM6DSL_H_
#define LSM6DSL_H_

#include "stdbool.h"
#include "stdint.h"


/// Define this constant if SPI is used (both 3 or 4 wires modes are supported)
#define LSM6DSL_SPI

#ifdef LSM6DSL_SPI

#define hspi_ag hspi2

#else

#define hi2c_ag hi2c2

// To be set according to the logic level on SA0 pin
#define LSM6DSL_I2C_ADDRESS			0xD4

#endif

////-------------CTRL1_XL------------------
#define LSM6DSL_REG_CTRL1_XL			0x10

#define LSM6DSL_REG_CTRL1_XL_ODR_SHIFT	4

/// Sampling frequency for XL_HM_MODE=0 and G_HM_MODE=0 (high performance acc/gyro)
typedef enum {
	LSM6DSL_ODR_POWER_DOWN=0x00,
	LSM6DSL_ODR_12dot5Hz=0x01 << LSM6DSL_REG_CTRL1_XL_ODR_SHIFT,
	LSM6DSL_ODR_26Hz=0x02 << LSM6DSL_REG_CTRL1_XL_ODR_SHIFT,
	LSM6DSL_ODR_52Hz=0x03 << LSM6DSL_REG_CTRL1_XL_ODR_SHIFT,
	LSM6DSL_ODR_104Hz=0x04 << LSM6DSL_REG_CTRL1_XL_ODR_SHIFT,
	LSM6DSL_ODR_208Hz=0x05 << LSM6DSL_REG_CTRL1_XL_ODR_SHIFT,
	LSM6DSL_ODR_416Hz=0x06 << LSM6DSL_REG_CTRL1_XL_ODR_SHIFT,
	LSM6DSL_ODR_833Hz=0x07 << LSM6DSL_REG_CTRL1_XL_ODR_SHIFT,
	LSM6DSL_ODR_1660Hz=0x08 << LSM6DSL_REG_CTRL1_XL_ODR_SHIFT,
	LSM6DSL_ODR_3330Hz=0x09 << LSM6DSL_REG_CTRL1_XL_ODR_SHIFT,
	LSM6DSL_ODR_6660Hz=0x0A << LSM6DSL_REG_CTRL1_XL_ODR_SHIFT
} LSM6DSL_ODR;

#define LSM6DSL_REG_CTRL1_XL_FS_SHIFT	2

typedef enum {
	LSM6DSL_REG_CTRL1_FS_2g=0x00 << LSM6DSL_REG_CTRL1_XL_FS_SHIFT,
	LSM6DSL_REG_CTRL1_FS_16g=0x01 << LSM6DSL_REG_CTRL1_XL_FS_SHIFT,
	LSM6DSL_REG_CTRL1_FS_4g=0x02 << LSM6DSL_REG_CTRL1_XL_FS_SHIFT,
	LSM6DSL_REG_CTRL1_FS_8g=0x03 << LSM6DSL_REG_CTRL1_XL_FS_SHIFT,
} LSM6DSL_REG_CTRL1_FS;

#define LSM6DSL_AXL_SENSITIVITY_2g	0.061
#define LSM6DSL_AXL_SENSITIVITY_4g	0.122
#define LSM6DSL_AXL_SENSITIVITY_8g	0.244
#define LSM6DSL_AXL_SENSITIVITY_16g	0.488

#define LSM6DSL_REG_CTRL1_XL_LPF1_SHIFT 1

typedef enum {
	LSM6DSL_REG_CTRL1_XL_LPF1_ENABLE=0x01, LSM6DSL_REG_CTRL1_XL_LPF1_DISABLE=0x00
} LSM6DSL_REG_CTRL1_XL_LPF1_BW_SEL;

typedef enum {
	LSM6DSL_REG_CTRL1_BW0_400Hz=0x01, LSM6DSL_REG_CTRL1_BW0_1500Hz=0x00
} LSM6DSL_REG_CTRL1_XL_BW0;


////-------------CTRL2_G------------------
#define LSM6DSL_REG_CTRL2_G				0x11

#define LSM6DSL_REG_CTRL2_G_FS_SHIFT		2

typedef enum {
	LSM6DSL_REG_CTRL2_G_FS_250dps=0x00 << LSM6DSL_REG_CTRL2_G_FS_SHIFT,
	LSM6DSL_REG_CTRL2_G_FS_500dps=0x01 << LSM6DSL_REG_CTRL2_G_FS_SHIFT,
	LSM6DSL_REG_CTRL2_G_FS_1000dps=0x02 << LSM6DSL_REG_CTRL2_G_FS_SHIFT,
	LSM6DSL_REG_CTRL2_G_FS_2000dps=0x03 << LSM6DSL_REG_CTRL2_G_FS_SHIFT,
} LSM6DSL_REG_CTRL2_G_FS;

#define LSM6DSL_GYRO_SENSITIVITY_250dps		8.75
#define LSM6DSL_GYRO_SENSITIVITY_500dps		17.5
#define LSM6DSL_GYRO_SENSITIVITY_1000dps	35
#define LSM6DSL_GYRO_SENSITIVITY_2000dps	70

////-------------CTRL3_C------------------

#define LSM6DSL_REG_CTRL3_C					0x12

// DEFAULT VALUE
// Interrupt outputs are active high
// INT1/INT2 push-pull
// Register autoincrement
// data LSM @ lower address
/// Note: if SPI 3-wire mode is enabled the default value is 0x04 | 0x08
#define LSM6DSL_REG_CTRL3_C_DEFAULT			0x04

#define LSM6DSL_REG_CTRL3_C_SPI3WIRE_ENABLE 0x08;

#define LSM6DSL_REG_CTRL3__C_BDU_SHIFT		6

typedef enum {
	LSM6DSL_REG_CTRL3_BDU_CONTINUOUS = 0x00 | LSM6DSL_REG_CTRL3_C_DEFAULT,
	LSM6DSL_REG_CTRL3_BDU_BLOCKING = (0x01 << LSM6DSL_REG_CTRL3__C_BDU_SHIFT)
			| LSM6DSL_REG_CTRL3_C_DEFAULT
} LSM6DSL_REG_CTRL3_C_BDU;


////-------------CTRL3_C------------------

#define LSM6DSL_REG_OUTX_L_G		0x22
#define LSM6DSL_REG_OUTX_H_G		0x23
#define LSM6DSL_REG_OUTY_L_G		0x24
#define LSM6DSL_REG_OUTY_H_G		0x25
#define LSM6DSL_REG_OUTZ_L_G		0x26
#define LSM6DSL_REG_OUTZ_H_G		0x27

#define LSM6DSL_REG_OUTX_L_XL		0x28
#define LSM6DSL_REG_OUTX_H_XL		0x29
#define LSM6DSL_REG_OUTY_L_XL		0x2A
#define LSM6DSL_REG_OUTY_H_XL		0x2B
#define LSM6DSL_REG_OUTZ_L_XL		0x2C
#define LSM6DSL_REG_OUTZ_H_XL		0x2D

#define LSM6DSL_REG_WHO_AM_I		0x0F

#define LSM6DSL_WHO_AM_I_CONTENT	0x6A

typedef enum {
	LSM6DSL_SPI_4WIRES, LSM6DSL_SPI_3WIRES, LSM6DSL_I2C
} LSM6DSL_Interface;

typedef struct {
	LSM6DSL_Interface comm_interface;
	LSM6DSL_ODR axl_odr;
	LSM6DSL_REG_CTRL1_FS axl_fs;
	LSM6DSL_REG_CTRL1_XL_LPF1_BW_SEL axl_lpf;
	LSM6DSL_REG_CTRL1_XL_BW0 axl_bw0;
	LSM6DSL_ODR gyro_odr;
	LSM6DSL_REG_CTRL2_G_FS gyro_fs;
	LSM6DSL_REG_CTRL3_C_BDU bdu;
} LSM6DSL_Init_TypeDef;

/**
 * Write LSM6DSL register(s)
 * @param regName		Register address
 * @param regValue		Value(s) to be written
 * @param numberOfBytes	Number of bytes to be written
 * @return				True if successful, false otherwise
 */
bool LSM6DSL_WriteReg(uint8_t regName, uint8_t* regValue, uint8_t numberOfBytes);

/**
 * Read LSM6DSL register(s)
 * @param regName		Register address
 * @param readByte		Read value(s)
 * @param numberOfBytes	Number of bytes to be read
 * @return				True if successful, false otherwise
 */
bool LSM6DSL_ReadReg(uint8_t regName, uint8_t* readByte, uint8_t numberOfBytes);

/**
 * Configuration of LSM6DSL operation
 * @param tempConfig	Initialization structure
 * @return				True if successful, false otherwise
 * @details				First function to be called for the correct operation of the sensor
 */
bool LSM6DSL_Config(LSM6DSL_Init_TypeDef tempConfig);

/**
 * Accelerometer power-down
 * @param arg			true (power-down), false (power-up)
 */
void LSM6DSL_axl_power_down(bool arg);

/**
 * Gyroscope power-down
 * @param arg			true (power-down), false (power-up)
 */
void LSM6DSL_gyro_power_down(bool arg);

/**
 * Read accelerometer samples
 * @param axl			Output accelerations (converted)
 * @param axlRaw		Raw output
 */
void LSM6DSL_read_axl(float* axl, uint16_t *axlRaw);

/**
 * Read gyroscope samples
 * @param gyro			Output angular speeds (converted)
 * @param gyroRaw		Raw output
 */
void LSM6DSL_read_gyro(float* gyro, uint16_t* gyroRaw);

/**
 * Read accelerometer and gyroscope samples
 * @param axl			Output accelerations (converted)
 * @param axlRaw		Raw accelerations output
 * @param gyro			Output angular speeds (converted)
 * @param gyroRaw		Raw gyro output
 */
void LSM6DSL_read_axl_gyro(float* axl, uint16_t *axlRaw, float* gyro, uint16_t* gyroRaw);

/**
 * Check WHO_AM_I register
 * @return				true if the content of WHO_AM_I register is correct, false otherwise
 */
bool LSM6DSL_check_WhoAmI(void);

/**
 * Set the accelerometer full-scale
 * @param fs			Accelerometer full-scale
 * @return				true if successful, false otherwise
 */
bool LSM6DSL_setAxlFS(LSM6DSL_REG_CTRL1_FS fs);

/**
 * Set the gyroscope full-scale
 * @param fs			Gyroscope full-scale
 * @return				true if successful, false otherwise
 */
bool LSM6DSL_setGyroFS(LSM6DSL_REG_CTRL2_G_FS fs);

#endif
