/**
 * @file    IO.h
 * @author  Andrea Pedrana - andrea.pedrana@unibg.it
 * @version 1.0
 * @date    17 July 2018
 * @brief   Implementation of IO module
 * @details Edit this file at your own risk
 * Universit� degli studi di Bergamo, Microlab
 */

#include "io.h"
#include "main.h"

/**
 * Toggle LEDs state
 */
void LED_Toggle(Leds xLeds){
	// LED_RED
	if((xLeds & LED_RED) == LED_RED){
		HAL_GPIO_TogglePin(LED_RED_GPIO_Port,LED_RED_Pin);
	}
	// LED_GREEN
	if((xLeds & LED_GREEN) == LED_GREEN){
		HAL_GPIO_TogglePin(LED_GREEN_GPIO_Port,LED_GREEN_Pin);
	}
	// LED_BLUE
	if((xLeds & LED_BLUE) == LED_BLUE){
		HAL_GPIO_TogglePin(LED_GREEN_GPIO_Port,LED_GREEN_Pin);
	}
}

/**
 * Switch on/off the LEDs
 */
void LED_Cmd(Leds xLeds, bool xState){
	// LED_RED
	if((xLeds & LED_RED) == LED_RED){
		xState == true ?
				HAL_GPIO_WritePin(LED_RED_GPIO_Port,LED_RED_Pin,GPIO_PIN_SET) :
				HAL_GPIO_WritePin(LED_RED_GPIO_Port,LED_RED_Pin,GPIO_PIN_RESET);
	}
	// LED_GREEN
	if((xLeds & LED_GREEN) == LED_GREEN){
		xState == true ?
				HAL_GPIO_WritePin(LED_GREEN_GPIO_Port,LED_GREEN_Pin,GPIO_PIN_SET) :
				HAL_GPIO_WritePin(LED_GREEN_GPIO_Port,LED_GREEN_Pin,GPIO_PIN_RESET);
	}
	// LED_BLUE
	if((xLeds & LED_BLUE) == LED_BLUE){
		xState == true ?
				HAL_GPIO_WritePin(LED_BLUE_GPIO_Port,LED_BLUE_Pin,GPIO_PIN_SET) :
				HAL_GPIO_WritePin(LED_BLUE_GPIO_Port,LED_BLUE_Pin,GPIO_PIN_RESET);
	}
}

/**
 * Enable/disable auxiliary supply
 */
void setVcc(bool xState){
	xState == true ?
			HAL_GPIO_WritePin(LOAD_EN_GPIO_Port,LOAD_EN_Pin,GPIO_PIN_SET) :
			HAL_GPIO_WritePin(LOAD_EN_GPIO_Port,LOAD_EN_Pin,GPIO_PIN_RESET);
}


void setLDO(bool xState){
	xState == true ?
			HAL_GPIO_WritePin(LDO_EN_GPIO_Port,LDO_EN_Pin,GPIO_PIN_SET) :
			HAL_GPIO_WritePin(LDO_EN_GPIO_Port,LDO_EN_Pin,GPIO_PIN_RESET);
}
