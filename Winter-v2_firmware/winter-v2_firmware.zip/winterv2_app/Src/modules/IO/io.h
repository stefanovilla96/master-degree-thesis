/**
 * @file    IO.h
 * @author  Andrea Pedrana - andrea.pedrana@unibg.it
 * @version 1.0
 * @date    April 26, 2020
 * @brief   Header file of IO module
 * @details Edit this file at your own risk
 * Universit� degli studi di Bergamo, Microlab
 */

#ifndef __IO_H
#define __IO_H

#include "stdbool.h"

typedef enum {
	LED_RED=0x01, LED_GREEN=0x02, LED_BLUE=0x04
} Leds;

/**
 * Toggle LEDs state
 * @param xLeds LED(s)
 */
void LED_Toggle(Leds xLeds);

/**
 * Switch on/off the LEDs
 * @param xLeds LED(s)
 * @param xState LED(s) state
 */
void LED_Cmd(Leds xLeds, bool xState);

/**
 * Enable/disable auxiliary supply
 * @param xState Auxiliary supply state
 */
void setVcc(bool xState);

/**
 * Enable/disable LDO for AD5940 and AD8232 supply
 * @param xState Supply state
 */
void setLDO(bool xState);

#endif /* __LEDS_H */
