#ifndef BLE_H_
#define BLE_H_

#include "stdbool.h"
#include "stdint.h"
#include "stm32l4xx_hal.h"
#include "stm32l4xx_it.h"

/**
 * @file    BLE.h
 * @author  Daniele Comotti - daniele.comotti@unibg.it daniele.comotti@221e.it
 * @version V1.0 alpha
 * @date    07 November 2016
 * @brief   BLE header file
 * @details Edit this file at your own risk
 * Universit� degli studi di Bergamo, Microelectronics Laboratory - 221e srl
 */

// Connection period, arg in msec.
#define CONN_P(x)   ((int)((x)/1.25f))
#define CONN_P1     (CONN_P(40))
#define CONN_P2     (CONN_P(40))
#define SCAN_P 		(0x200)
#define SCAN_L 		(0x200)

#define BLE_JOB_IRQn			TIM2_IRQn

//#define BLE_JOB_IRQHandler	TIM2_IRQHandler

#define BLE_NAME_LEN	15 // Max length of the BLE name in bytes, '\0' included

#define BLE_JOB_IRQn_Priority 4

#define BNRG_SPI_EXTI_IRQn_Priority 3

typedef struct {
	bool connected;
	uint8_t bd_address[6];
	bool state;
	char name[BLE_NAME_LEN];
} BLE_TypeDef;

////////////////////////////
#define BLE_CMD_MAX_LEN		16

typedef struct{
	bool updateChar;
	uint8_t respValue[BLE_CMD_MAX_LEN];
	uint8_t respLen;
}BLE_Config;


////////////////////////////

bool BLE_init(void);

bool BLE_Services_Init(void);

void BLE_setConnectable(void);

void GAP_ConnectionComplete_CB(uint8_t addr[6], uint16_t handle);

void GAP_DisconnectionComplete_CB(void);

void BLE_doJob(void);

bool BLE_setName(uint32_t* arg);

void BLE_setIRQs(bool arg);

void BLE_deInit(void);

bool BLE_Connected(void);

bool BLE_getState(void);

void BLE_getBDAddress(uint8_t* bd);

bool BLE_getConnected(void);

void BLE_refresh(void);

#endif
