#ifndef _COMM_H_
#define _COMM_H_

#include "ble_status.h"
#include "bluenrg_gatt_aci.h"


bool Evaluate_Command(uint8_t *cmdData, uint8_t dataLen, uint8_t* cmdResponse, uint8_t* responseLen) ;

typedef enum {
	CMD_SHUTDOWN = 0x01,	//!< CMD_SHUTDOWN
	CMD_STATE = 0x02,		//!< CMD_STATE (SET/GET THE STATE)
	CMD_RESTART = 0x03,     //!< CMD_RESTART
	CMD_DATE = 0x04,		//!< CMD_DATE
	CMD_START_LOG = 0x05,	//!< CMD_START_LOG
	CMD_STOP=0x06,			//!< CMD_STOP
	CMD_ACK=0x00			//!< CMD_ACK
} Cmd; //Command

typedef enum{
	ACK_SUCCESS=0x00,
	ACK_ERROR=0x01
}Ack_Typedef;


uint8_t frequency;
uint8_t mode;
#endif /* _COMM_H_ */
