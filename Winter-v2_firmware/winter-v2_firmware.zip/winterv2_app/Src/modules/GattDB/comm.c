#include "../app.h"
#include "../BLE/ble.h"
#include "bluenrg_aci.h"
#include "bluenrg_gap.h"
#include "bluenrg_gatt_server.h"
#include "gatt_db.h"
#include "hal.h"
#include "hal_types.h"
#include "main.h"
#include "stdbool.h"
#include "string.h"
#include "gatt_db.h"
#include "IO/io.h"
#include <stdio.h>
#include "comm.h"

#ifdef NDEBUG
#define PRINTF(...)
#else
#define PRINTF(...) printf(__VA_ARGS__)
#endif

#define CHECK_STATUS_RETURN(x) if (x != BLE_STATUS_SUCCESS) return
#define CHECK_STATUS_RETVAL(x) if (x != BLE_STATUS_SUCCESS) return x

extern uint16_t handle_comm_serv; //servizio di comunicazione comandi
extern uint16_t handle_comm_value;

// Struttura pacchetti TLV
// |	TYPE	|	LENGTH	|	VALUE	|
// |	8 bit	|	8 bit	| 	48 bit	|

bool Evaluate_Command(uint8_t *cmdData, uint8_t dataLen, uint8_t* cmdResponse,
		uint8_t* responseLen) {

	bool read = (cmdData[0] & 0x80) != 0;
	uint8_t payloadLen = cmdData[1];

	bool updateValue = true;

	*responseLen = 4;
	cmdResponse[0] = CMD_ACK;
	cmdResponse[1] = 2;
	cmdResponse[2] = cmdData[0];
	cmdResponse[3] = ACK_ERROR;

	switch (cmdData[0] & 0x7F) {
	case CMD_SHUTDOWN:
		break;
	case CMD_STATE:
		if (!read) {
			if (payloadLen == 1) {
				setSystemState(cmdData[2]);
				cmdResponse[3] = ACK_SUCCESS;
			}
		} else {
			if (payloadLen == 0) {
				*responseLen = 5;
				cmdResponse[4] = getSystemState();
				cmdResponse[3] = ACK_SUCCESS;
			}
		}
		break;
	case CMD_RESTART:
		if (!read) {
			if (payloadLen == 0) {
				updateLastActivityTime();
				setScheduledOperation(OP_RESTART);
				cmdResponse[3] = ACK_SUCCESS;
			}
		}
		break;
	case CMD_DATE:
		break;
	case CMD_START_LOG:
		if (!read) {
			if (payloadLen == 2) {
				//TODO
				cmdResponse[3] = ACK_SUCCESS;
				setSystemState(APP_LOG);
			}
		}
		break;
	case CMD_STOP:
		if (!read){
			if (payloadLen == 0) {
				setSystemState(APP_IDLE);
				cmdResponse[3] = ACK_SUCCESS;
			}
		}
		break;
	default:
		break;
	}
	return updateValue;
}

