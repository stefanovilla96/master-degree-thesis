#ifndef _GATT_DB_H_
#define _GATT_DB_H_

#include "ble_status.h"
#include "bluenrg_gatt_aci.h"

tBleStatus Add_BLE_Service_DeviceInformation(void);

tBleStatus Add_BLE_Service_Battery(void);

tBleStatus Add_BLE_Service_Environmental_Sensing(void);

tBleStatus Add_BLE_Service_Log(void);

tBleStatus Add_BLE_Service_Communication(void);

void Read_Request_CB(evt_gatt_read_permit_req const *evt);

void Attribute_Modified_CB(evt_gatt_attr_modified const *evt);

void updateTemperature(int16_t temp);

#endif /* _GATT_DB_H_ */
