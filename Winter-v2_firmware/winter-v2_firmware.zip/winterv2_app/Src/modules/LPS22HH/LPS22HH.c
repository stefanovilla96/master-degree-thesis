/**
 * @file    LPS22HB.c
 * @author  Andrea Pedrana - andrea.pedrana@unibg.it
 * @version 1.0
 * @date    2019/06/13
 * @brief   Header of the LPS22HB driver
 * @details For SPI 3-wires mode, set "Half Duplex Master" in STM32Cube MX. SPI_1LINE_TX(&hspix) and SPI_1LINE_RX(&hspix) calls
 * are used to alternate the transmission direction (needed only when reading something)
 * Universit� degli studi di Bergamo, Microelectronics Laboratory
 */

#include "LPS22HH.h"
#include "string.h"
#include "main.h"

#ifdef LPS22HH_SPI

extern SPI_HandleTypeDef hspi_pt;

#else

extern I2C_HandleTypeDef hi2c_pt;

#endif

LPS22HH_Init_TypeDef pt_init;

// Definition of static SPI/I2C read/write functions
#ifdef LPS22HH_SPI

static bool LPS22HH_SPI_Write(uint8_t regName, uint8_t* regValue, uint8_t numberOfBytes);

static bool LPS22HH_SPI_Read(uint8_t regName, uint8_t* readByte, uint8_t numberOfBytes);

#else

static bool LPS22HH_I2C_Write(uint8_t regName, uint8_t* regValue, uint8_t numberOfBytes);

static bool LPS22HH_I2C_Read(uint8_t regName, uint8_t* readByte, uint8_t numberOfBytes);

#endif

LPS22HH_Init_TypeDef pressureInit;

/**
 * Write LPS22HB register(s)
 */
bool LPS22HH_WriteReg(uint8_t regName, uint8_t* regValue, uint8_t numberOfBytes){
#ifdef LPS22HH_SPI
	return LPS22HH_SPI_Write(regName,regValue,numberOfBytes);
#else
	return LPS22HH_I2C_Write(regName,regValue,numberOfBytes);
#endif
}

/**
 * Read LPS22HB register(s)
 */
bool LPS22HH_ReadReg(uint8_t regName, uint8_t* readByte, uint8_t numberOfBytes){
#ifdef LPS22HH_SPI
	return LPS22HH_SPI_Read(regName,readByte,numberOfBytes);
#else
	return LPS22HH_I2C_Read(regName,readByte,numberOfBytes);
#endif
}

#ifdef LPS22HH_SPI

static bool LPS22HH_SPI_Write(uint8_t regName, uint8_t* regValue, uint8_t numberOfBytes){
	bool result= true;
	/// Tight low CS
	HAL_GPIO_WritePin(CS_P_GPIO_Port,CS_P_Pin,GPIO_PIN_RESET);

	/// Mask in order to have 0 as MSb of the address byte
	regName=regName & 0x7F;

	uint8_t tx_buffer[numberOfBytes + 1];
	uint8_t i;
	tx_buffer[0]=regName;
	for(i=0;i < numberOfBytes;i++)
		tx_buffer[i + 1]=regValue[i];

	result&=HAL_SPI_Transmit(&hspi_pt,tx_buffer,numberOfBytes + 1,100) == HAL_OK;

	/// Tight high CS
	HAL_GPIO_WritePin(CS_P_GPIO_Port,CS_P_Pin,GPIO_PIN_SET);
	return result;
}

static bool LPS22HH_SPI_Read(uint8_t regName, uint8_t* readByte, uint8_t numberOfBytes){
	bool result= true;
	/// Tight low CS
	HAL_GPIO_WritePin(CS_P_GPIO_Port,CS_P_Pin,GPIO_PIN_RESET);

	/// Mask in order to have 1 as MSb of the address byte
	regName|=0x80;

	result&=HAL_SPI_Transmit(&hspi_pt,&regName,1,100);

	/// Set unidirectional line TX
	if(pt_init.comm_interface == LPS22HH_SPI_3WIRES){
		SPI_1LINE_RX(&hspi_pt);
	}

	result&=HAL_SPI_Receive(&hspi_pt,readByte,numberOfBytes,100);

	/// Tight high CS
	HAL_GPIO_WritePin(CS_P_GPIO_Port,CS_P_Pin,GPIO_PIN_SET);

	/// Set again unidirectional TX
	if(pt_init.comm_interface == LPS22HH_SPI_3WIRES){
		SPI_1LINE_TX(&hspi_pt);
	}

	return result;
}

#else

/**
 * I2C write
 */
static bool LPS22HH_I2C_Write(uint8_t regName, uint8_t* regValue, uint8_t numberOfBytes){
	bool result= true;

	uint8_t tx_buffer[numberOfBytes + 1];
	uint8_t i;
	tx_buffer[0]=regName;
	for(i=0;i < numberOfBytes;i++)
		tx_buffer[i + 1]=regValue[i];

	result&=HAL_I2C_Master_Transmit(&hi2c_pt,LPS22HH_I2C_ADDRESS,tx_buffer,numberOfBytes + 1,100) == HAL_OK;

	return result;
}

/**
 * I2C read
 */
static bool LPS22HH_I2C_Read(uint8_t regName, uint8_t* readByte, uint8_t numberOfBytes){
	bool result= true;

	result&=HAL_I2C_Master_Transmit(&hi2c_pt,LPS22HH_I2C_ADDRESS,&regName,1,100) == HAL_OK;

	result&=HAL_I2C_Master_Receive(&hi2c_pt,LPS22HH_I2C_ADDRESS,readByte,numberOfBytes,100) == HAL_OK;

	return result;
}

#endif

/**
 * Check WHO_AM_I register
 */
bool LPS22HH_CheckWhoAmI(void){
	uint8_t temp;
	LPS22HH_ReadReg(LPS22HH_REG_WHO_AM_I,&temp,1);
	return (temp == LPS22HH_WHO_AM_I_CONTENT) ? true : false;
}

/**
 * Configuration of LPS22HB operation
 */
bool LPS22HH_Config(LPS22HH_Init_TypeDef initStruct){
	uint8_t temp, check;
	bool result=true;

	//Store configuration parameters
	memcpy((uint8_t*)&pt_init,(uint8_t*)&initStruct,sizeof(LPS22HH_Init_TypeDef));

	/// CTRL_REG1
	temp=initStruct.pt_bandwidth | initStruct.pt_bdu | initStruct.pt_odr;
#ifdef LPS22HH_SPI
	if(initStruct.comm_interface == LPS22HH_SPI_3WIRES){
		/// Set 1 direction TX mode
		SPI_1LINE_TX(&hspi_pt);
		temp|=LPS22HH_REG_CTRL_REG1_SPI3WIRE_ENABLE
		;
	}
#endif
	result&=LPS22HH_WriteReg(LPS22HH_REG_CTRL_REG1,&temp,1);
	result&=LPS22HH_ReadReg(LPS22HH_REG_CTRL_REG1,&check,1);
	result&=(temp == check);

	return result;
}

/**
 * LPS22HB soft reset
 */
bool LPS22HH_Reset(void){
	uint8_t temp;
	bool result=true;

	result&=LPS22HH_ReadReg(LPS22HH_REG_CTRL_REG2,&temp,1);
	temp|=LPS22HH_REG_CTRL_REG2_SWRESET;
	result&=LPS22HH_WriteReg(LPS22HH_REG_CTRL_REG2,&temp,1);

	return result;
}

/**
 * Sensor power-down
 */
bool LPS22HH_setPowerDown(bool arg){
	uint8_t temp;
	bool result=true;

	result&=LPS22HH_ReadReg(LPS22HH_REG_CTRL_REG1,&temp,1);

	if((temp & 0x8F) != 0x00){
		/// Device is active, put it in power down mode if needed
		if(arg){
			temp=temp & 0x8F;
			result&=LPS22HH_WriteReg(LPS22HH_REG_CTRL_REG1,&temp,1);
		}
	}else{
		if(!arg){
			/// Device is powered down, turn it on
			temp=temp | pt_init.pt_odr;
			result&=LPS22HH_WriteReg(LPS22HH_REG_CTRL_REG1,&temp,1);
		}
	}
	return result;
}

/**
 * Read pressure and temperature
 */
bool LPS22HH_ReadData(float* p, float* t, uint8_t* raw_p, uint8_t* raw_t){
	uint8_t temp[5];
	uint8_t i;
	uint32_t pressValue;
	bool result=true;
	pressValue=0;

	/// Readout pressure and temperature
	result&=LPS22HH_SPI_Read(LPS22HH_REG_PRESS_OUT_XL,temp,5);

	/// Convert pressure
	for(i=0;i < 3;i++){
		raw_p[2-i]=temp[i]; // MSB first
		pressValue=pressValue + (temp[i] << (i * 8));
	}
	pressValue=pressValue << 8;
	*p=(float)(*((int32_t*)&pressValue));
	*p/=256;
	*p/= LPS22HH_Pressure_Sensitivity;

	/// Convert temperature
	uint16_t tempValue;
	tempValue=0;
	for(i=0;i < 2;i++){
		raw_t[1-i]=temp[i+3]; // MSB first
		tempValue=tempValue + (temp[i+3] << (i * 8));
	}
	*t=(float)(*((int16_t*)&tempValue));
	*t/= LPS22HH_Temperature_Sensitivity;

	return result;
}
