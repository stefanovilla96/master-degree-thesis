/**
 * @file    LPS22HB.h
 * @author  Andrea Pedrana - andrea.pedrana@unibg.it
 * @version 1.0
 * @date    2019/06/13
 * @brief   Header of the LPS22HB driver
 * Universit� degli studi di Bergamo, Microelectronics Laboratory
 */

#ifndef LPS22HH_H_
#define LPS22HH_H_

#include "stdbool.h"
#include "stdint.h"

/// Define this constant if SPI is used (both 3 or 4 wires modes are supported)
//#define LPS22HH_SPI

#ifdef LPS22HH_SPI

#define hspi_pt	hspi2

#else

#define hi2c_pt hi2c2

// To be set according to the logic level on SA0 pin
#define LPS22HH_I2C_ADDRESS			0xBA

#endif


#define LPS22HH_REG_INTERRUPT_CFG		0x0B

#define LPS22HH_REG_THS_P_L				0x0C
#define LPS22HH_REG_THS_P_H				0x0D

#define LPS22HH_REG_WHO_AM_I			0x0F

#define LPS22HH_REG_CTRL_REG1			0x10
#define LPS22HH_REG_CTRL_REG2			0x11
#define LPS22HH_REG_CTRL_REG3			0x12

#define LPS22HH_REG_FIFO_CTRL			0x14

#define LPS22HH_REG_REF_P_XL			0x15
#define LPS22HH_REG_REF_P_L				0x16
#define LPS22HH_REG_REF_P_H				0x17

#define LPS22HH_REG_RPDS_L				0x18
#define LPS22HH_REG_RPDS_H				0x19

#define LPS22HH_REG_RES_CONF			0x1A

#define LPS22HH_REG_INT_SOURCE			0x25

#define LPS22HH_REG_FIFO_STATUS			0x26

#define LPS22HH_REG_STATUS				0x27

#define LPS22HH_REG_PRESS_OUT_XL		0x28
#define LPS22HH_REG_PRESS_OUT_L			0x29
#define LPS22HH_REG_PRESS_OUT_H			0x2A

#define LPS22HH_REG_TEMP_OUT_L			0x2B
#define LPS22HH_REG_TEMP_OUT_H			0x2C

#define LPS22HH_REG_LPFP_RES			0x33

/// WHO_AM_I registers content
#define LPS22HH_WHO_AM_I_CONTENT		0xB3

////-------------CTRL_REG1------------------
#define LPS22HH_REG_CTRL_REG1_ODR_SHIFT	4

typedef enum {
	LPS22HH_REG_CTRL_REG1_ODR_POWER_DOWN = 0x00 << LPS22HH_REG_CTRL_REG1_ODR_SHIFT,
	LPS22HH_REG_CTRL_REG1_ODR_1Hz = 0x01 << LPS22HH_REG_CTRL_REG1_ODR_SHIFT,
	LPS22HH_REG_CTRL_REG1_ODR_10Hz = 0x02 << LPS22HH_REG_CTRL_REG1_ODR_SHIFT,
	LPS22HH_REG_CTRL_REG1_ODR_25Hz = 0x03 << LPS22HH_REG_CTRL_REG1_ODR_SHIFT,
	LPS22HH_REG_CTRL_REG1_ODR_50Hz = 0x04 << LPS22HH_REG_CTRL_REG1_ODR_SHIFT,
	LPS22HH_REG_CTRL_REG1_ODR_75Hz = 0x05 << LPS22HH_REG_CTRL_REG1_ODR_SHIFT
} LPS22HH_REG_CTRL_REG1_ODR;

#define LPS22HH_REG_CTRL_REG1_BW_SHIFT	2

typedef enum {
	LPS22HH_REG_CTRL_REG1_BW_ODR_2=0x00 << LPS22HH_REG_CTRL_REG1_BW_SHIFT,
	LPS22HH_REG_CTRL_REG1_BW_ODR_9=0x02 << LPS22HH_REG_CTRL_REG1_BW_SHIFT,
	LPS22HH_REG_CTRL_REG1_BW_ODR_20=0x03 << LPS22HH_REG_CTRL_REG1_BW_SHIFT
} LPS22HH_REG_CTRL_REG1_BW;

#define LPS22HH_REG_CTRL_REG1_BDU_SHIFT	1

typedef enum {
	LPS22HH_REG_CTRL_REG1_BDU_CONTINUOUS=0x00 << LPS22HH_REG_CTRL_REG1_BDU_SHIFT,
	LPS22HH_REG_CTRL_REG1_BDU_BLOCKING=0x01 << LPS22HH_REG_CTRL_REG1_BDU_SHIFT
} LPS22HH_REG_CTRL_REG1_BDU;

#define LPS22HH_REG_CTRL_REG1_SPI3WIRE_ENABLE 0x01;

typedef enum {
	LPS22HH_SPI_4WIRES, LPS22HH_SPI_3WIRES, LPS22HH_I2C
} LPS22HH_Interface;

typedef struct {
	LPS22HH_Interface comm_interface;
	LPS22HH_REG_CTRL_REG1_ODR pt_odr;
	LPS22HH_REG_CTRL_REG1_BW pt_bandwidth;
	LPS22HH_REG_CTRL_REG1_BDU pt_bdu;
} LPS22HH_Init_TypeDef;

#define LPS22HH_REG_CTRL_REG2_SWRESET	0x04

#define	LPS22HH_Pressure_Sensitivity	4096	// LSB/hPa
#define	LPS22HH_Temperature_Sensitivity	100		// LSB/�C

/**
 * Write LPS22HB register(s)
 * @param regName		Register address
 * @param regValue		Value(s) to be written
 * @param numberOfBytes	Number of bytes to be written
 * @return				True if successful, false otherwise
 */
bool LPS22HH_WriteReg(uint8_t regName, uint8_t* regValue, uint8_t numberOfBytes);

/**
 * Read LPS22HB register(s)
 * @param regName		Register address
 * @param readByte		Read value(s)
 * @param numberOfBytes	Number of bytes to be read
 * @return				True if successful, false otherwise
 */
bool LPS22HH_ReadReg(uint8_t regName, uint8_t* readByte, uint8_t numberOfBytes);

/**
 * Check WHO_AM_I register
 * @return				true if the content of WHO_AM_I registers is correct, false otherwise
 */
bool LPS22HH_CheckWhoAmI(void);

/**
 * Configuration of LPS22HB operation
 * @param pInit			Initialization structure
 * @return				True if successful, false otherwise
 * @details				First function to be called for the correct operation of the sensor
 */
bool LPS22HH_Config(LPS22HH_Init_TypeDef pInit);

/**
 * LPS22HB soft reset
 * @return				True if successful, false otherwise
 */
bool LPS22HH_Reset(void);

/**
 * Sensor power-down
 * @param arg			true (power-down), false (power-up)
 * @return				True if successful, false otherwise
 */
bool LPS22HH_setPowerDown(bool arg);

/**
 * Read pressure and temperature
 * @param p				Pressure
 * @param t				Temperature
 * @param raw_p			Raw pressure (3 Bytes)
 * @param raw_t			Raw temperature (2 Bytes)
 * @return				True if successful, false otherwise
 */
bool LPS22HH_ReadData(float* p, float* t, uint8_t* raw_p, uint8_t* raw_t);

#endif
