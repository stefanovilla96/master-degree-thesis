/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdint.h"
#include "stdbool.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define CS_AG_Pin GPIO_PIN_13
#define CS_AG_GPIO_Port GPIOC
#define ECG_RESET_Pin GPIO_PIN_0
#define ECG_RESET_GPIO_Port GPIOC
#define BIOZ_INT_Pin GPIO_PIN_1
#define BIOZ_INT_GPIO_Port GPIOC
#define BIOZ_INT_EXTI_IRQn EXTI1_IRQn
#define INT_ACC_Pin GPIO_PIN_0
#define INT_ACC_GPIO_Port GPIOA
#define SDMMC_CD_Pin GPIO_PIN_1
#define SDMMC_CD_GPIO_Port GPIOA
#define BLUE_IRQ_Pin GPIO_PIN_2
#define BLUE_IRQ_GPIO_Port GPIOA
#define SPI2_CS_Pin GPIO_PIN_3
#define SPI2_CS_GPIO_Port GPIOA
#define LOAD_EN_Pin GPIO_PIN_4
#define LOAD_EN_GPIO_Port GPIOC
#define LED_GREEN_Pin GPIO_PIN_5
#define LED_GREEN_GPIO_Port GPIOC
#define LED_RED_Pin GPIO_PIN_0
#define LED_RED_GPIO_Port GPIOB
#define LED_BLUE_Pin GPIO_PIN_1
#define LED_BLUE_GPIO_Port GPIOB
#define BLUE_CS_Pin GPIO_PIN_2
#define BLUE_CS_GPIO_Port GPIOB
#define BLUE_RST_Pin GPIO_PIN_11
#define BLUE_RST_GPIO_Port GPIOB
#define BATT_STAT_Pin GPIO_PIN_12
#define BATT_STAT_GPIO_Port GPIOB
#define LDO_EN_Pin GPIO_PIN_9
#define LDO_EN_GPIO_Port GPIOA
#define BIOZ_RESET_Pin GPIO_PIN_15
#define BIOZ_RESET_GPIO_Port GPIOA
/* USER CODE BEGIN Private defines */
typedef enum {
	I2C_GAS_GAUGE=1, I2C_HUM=2
} I2C_Number;

bool I2CWrite(uint8_t address, uint8_t* data, uint8_t numberOfBytes, I2C_Number i2c_num);
bool I2CRead(uint8_t address, uint8_t regName, uint8_t* data, uint8_t numberOfBytesToRead, I2C_Number i2c_num);

void EnterLowPowerRunMode(void);

void ExitLowPowerRunMode(void);

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
