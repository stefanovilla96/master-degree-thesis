	/*
 * app.c
 *
 *  Created on: 11 giu 2020
 *      Author: Stefano Villa
 */


#include "app.h"
#include "main.h"
#include "stm32l4xx_hal_adc.h"
#include "tx_rx.h"

ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

volatile myEDA edaBoard;
uint16_t adc_buf[ADC_BUFFER_LEN];


void doJob(void){
	switch(edaBoard.state){
	case APP_IDLE:
		HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
		HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);
		HAL_ADC_Stop_DMA(&hadc1);
		break;
	case APP_STREAM:
		HAL_ADC_Start_DMA(&hadc1,(uint32_t*)adc_buf,ADC_BUFFER_LEN);
		break;
	case APP_ERROR:
		initSystem();
		break;
	default:
		break;
	}
}

void setSystemState(SystemState s){
	edaBoard.state = s;
}


SystemState getState(){
	return edaBoard.state;
}

void initSystem(void){
	edaBoard.app_period = 250;
	setSystemState(APP_STARTUP);
	HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);

	HAL_NVIC_SetPriority(APP_JOB_IRQn, APP_JOB_Priority, 0);
	HAL_NVIC_EnableIRQ(APP_JOB_IRQn);

	HAL_Delay(500);
	HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);

	setSystemState(APP_IDLE);
}
