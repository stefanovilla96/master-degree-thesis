/*
 * comm.h
 *
 *  Created on: 13 feb 2020
 *      Author: andre
 */

#ifndef COMM_H_
#define COMM_H_

#include "main.h"

#define COMM_BUFFER_SIZE 10

void COMM_TransmitBuffer(uint16_t value);

#endif /* COMM_H_ */
