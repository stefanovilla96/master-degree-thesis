/*
 * app.h
 *
 *  Created on: 11 giu 2020
 *      Author: Stefano Villa
 */

#ifndef APP_H_
#define APP_H_

#include "stdint.h"

#define APP_JOB_IRQn CAN1_TX_IRQn
#define APP_JOB_Priority 5

typedef enum{
	APP_STARTUP = 0x00,
	APP_IDLE = 0x01,
	APP_STREAM = 0x02,
	APP_ERROR = 0xFF
}SystemState;

typedef enum{
	READ = 0x80,
	WRITE = 0x00
}R_W;

typedef enum{
	RESTART = 0x00,
	STATE = 0x01,
	STREAM = 0x02,
	STOP_STREAM = 0x03
}CMD;

typedef enum{
	ACK_CODE = 0x00,
	ACK_SUCCESS = 0x00,
	ACK_ERROR = 0x01
}ACK;

typedef struct{
	SystemState state;
	uint16_t app_period;
}myEDA;

void initSystem(void);
SystemState getState();
void setSystemState(SystemState s);
void doJob(void);

#endif /* APP_H_ */
