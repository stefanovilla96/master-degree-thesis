/*
 * comm.c
 *
 *  Created on: 13 feb 2020
 *      Author: andre
 */

#include "comm.h"
#include "tx_rx.h"
#include "usbd_cdc_if.h"


void COMM_TransmitBuffer(uint16_t value){
	streamData(value);
}

