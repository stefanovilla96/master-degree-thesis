/*
 * tx_rx.c
 *
 *  Created on: 16 giu 2020
 *      Author: Stefano Villa
 */


#include "tx_rx.h"
#include "app.h"
#include "usbd_cdc_if.h"
#include "main.h"
#include "stdbool.h"

volatile uint8_t buffer[MAX_BUFFER_SIZE];
volatile myEDA edaBoard;
uint16_t len = 0;
uint8_t payload_length = 0;

uint8_t buf_index = 4;

bool check(uint8_t* Buf, uint32_t Len){
	if(Buf[0] == HEADER && Buf[1] == HEADER){
		if(Buf[Len - 1] == TRAILER && Buf[Len - 2] == TRAILER){
			return true;
		}
	}
	return false;
}

void trasmitt(uint8_t* buf){

	buffer[0] = HEADER;
	buffer[1] = HEADER;
	buffer[2] = ACK_CODE;
	buffer[5] = ACK_SUCCESS;

	if(buf[2] == (RESTART | WRITE)){
		initSystem();

		payload_length = 0x03;//lunghezza
		buffer[3] = payload_length;
		buffer[4] = 0x03;//payload

	}
	else{

	}

	if(buf[2] == (STATE | READ)){

		payload_length = 0x03; //lunghezza
		buffer[3] = payload_length;
		buffer[4] = 0x82; //payload
		buffer[6] = edaBoard.state; //payload
	}
	else{

	}

	if(buf[2] == (STREAM | READ)){
		setSystemState(APP_STREAM);
	}
	else{

	}

	if(buf[2] == (STOP_STREAM | WRITE)){
		payload_length = 0x02;
		buffer[3] = payload_length;
		buffer[4] = 0x04;
		setSystemState(APP_IDLE);

	}

	buffer[3 + payload_length + 1] = TRAILER;
	buffer[3 + payload_length + 2] = TRAILER;
	len = 3 + payload_length + 3;
	CDC_Transmit_FS(buffer, len);
}

void streamData(uint16_t value){

	buffer[2] = STREAM;

	payload_length = 0x04;
	buffer[3] = payload_length;

	buffer[buf_index]=(uint8_t)((value & 0x0F00) >> 8); // 8bit pi� significativi di value
	buffer[buf_index + 1]=(uint8_t)(value & 0x00FF); // 8bit meno significativi di value

	buf_index += 2;

	if(buf_index >= MAX_BUFFER_SIZE){
		buffer[0] = HEADER;
		buffer[1] = HEADER;

		buffer[3 + payload_length + 1] = TRAILER;
		buffer[3 + payload_length + 2] = TRAILER;
		CDC_Transmit_FS(buffer, MAX_BUFFER_SIZE);
		buf_index = 4;
	}
}


/*
 *
 *
 *
 */
