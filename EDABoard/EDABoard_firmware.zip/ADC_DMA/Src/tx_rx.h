/*
 * tx_rx.h
 *
 *  Created on: 16 giu 2020
 *      Author: Stefano Villa
 */

#ifndef TX_RX_H_
#define TX_RX_H_

#include "stdint.h"
#include "stdbool.h"

#define MAX_BUFFER_SIZE 10

//4 header trailer
//1 cmd
//1 lunghezza
//6 payload

#define HEADER '<'
#define TRAILER '>'

void trasmitt(uint8_t* buf);
bool check(uint8_t* Buf, uint32_t Len);
void streamData(uint16_t value);
void emptyBuffer(uint8_t* buffer);
#endif /* TX_RX_H_ */
