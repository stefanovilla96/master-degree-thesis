package frame;

public interface FormSettings {
	public void createFrame();

	public void attachSettingsComponents();

	public void setButtonProprietiesSettings();

	public void attachGameComponents();

	public void setButtonProprietiesGame();
}
