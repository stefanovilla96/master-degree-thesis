package frame;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSpinner;
import javax.swing.Timer;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;

import com.fazecast.jSerialComm.SerialPort;

import plot.DynamicTimeSeriesChart;
import plot.Plot;
import serial.SerialWriteRead;



public class Game {

	private static String question;
	private static long questionTime;
	public static Thread gameTime;
	public static Timer timer;

	public static void startGame(DynamicTimeSeriesChart chart, JPanel contentPane, HSSFWorkbook workbook, HSSFSheet sheet, ArrayList<Integer> edaMeasure, ArrayList<Long> questionTimeArray, ArrayList<Long> answerTimeArray, 
			ArrayList<Long> deltaTimeArray, ArrayList<String> questionTextArray,  ArrayList<String> answerTextArray, ArrayList<Boolean> answerArray, long startTime, JSpinner gameLength, JProgressBar progressBar, JPanel answerPanel, JButton playStopBtn, JLabel lblGameDurationIn, JButton redAnswerButton, JButton greenAnswerBtn, JButton yellowAnswerBtn, JButton blueAnswerButton, SerialPort serialPort) {

		clock(contentPane, workbook, sheet, edaMeasure, questionTimeArray, answerTimeArray, deltaTimeArray, questionTextArray, answerTextArray, answerArray, startTime, gameLength, progressBar, serialPort);
		updateGraph(chart);
		gameLength.setVisible(false);
		lblGameDurationIn.setVisible(false);

		progressBar.setVisible(true);

		playStopBtn.setText("STOP");

		answerPanel.setVisible(true);
		redAnswerButton.setEnabled(true);
		greenAnswerBtn.setEnabled(true);
		blueAnswerButton.setEnabled(true);
		yellowAnswerBtn.setEnabled(true);
	}


	public static void chooseQuestion(Color[] colors, String[] questions, JLabel questionLabel) {
		Random randomColor = new Random();
		Random randomQuestion = new Random();
		int randomColorIndex = randomColor.nextInt(colors.length);
		int randomQuestionIndex = randomQuestion.nextInt(questions.length);



		if(colors[randomColorIndex].getGreen() == 255 && colors[randomColorIndex].getRed() == 0) {
			question = "Green";

		}

		if(colors[randomColorIndex].getBlue() == 255 && colors[randomColorIndex].getRed() == 0 && colors[randomColorIndex].getGreen() == 0) {
			question = "Blue";

		}

		if(colors[randomColorIndex].getRed() == 255 && colors[randomColorIndex].getGreen() == 0 && colors[randomColorIndex].getBlue() == 0) {
			question = "Red";

		}

		if(colors[randomColorIndex].getGreen() == 255 && colors[randomColorIndex].getRed() == 255 && colors[randomColorIndex].getBlue() == 0) {
			question = "Yellow";
		}


		questionLabel.setText(questions[randomQuestionIndex]);
		questionLabel.setForeground(colors[randomColorIndex]);

		questionTime = System.currentTimeMillis();
	}


	private static void clock(JPanel contentPane, HSSFWorkbook workbook, HSSFSheet sheet, ArrayList<Integer> edaMeasure, ArrayList<Long> questionTimeArray, ArrayList<Long> answerTimeArray, 
			ArrayList<Long> deltaTimeArray, ArrayList<String> questionTextArray,  ArrayList<String> answerTextArray, ArrayList<Boolean> answerArray, long startTime, JSpinner gameLength, JProgressBar progressBar, SerialPort serialPort) {
		//timeAxis = new ArrayList<Long>();

		gameTime = new Thread() {
			public void run() {

				int length = (int)gameLength.getValue();
				int duration = length * 60 * 1000;

				float val = 0;
				float incr = (float) (100.0/(length*60));
				try {
					while(startTime + duration >= System.currentTimeMillis()) {
						val += incr;
						progressBar.setValue((int) val);
						//timeAxis.add(System.currentTimeMillis());
						sleep(1000);
					}
					JOptionPane.showMessageDialog(null, "Test concluso");

					SerialWriteRead.getInstance(serialPort).sendCmd(serial.Command.CMD_STOP_STREAM.getCmdByte(), serial.Command.WRITE.getCmdByte(), (byte) 0);
					
					
					saveXLSFile(contentPane, workbook, sheet, questionTimeArray, answerTimeArray, deltaTimeArray, questionTextArray, answerTextArray, answerArray, edaMeasure);

					contentPane.setVisible(false);

					

					//System.err.println(timeAxis.size());
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		gameTime.start();
	}

	public static void saveXLSFile(JPanel contentPane, HSSFWorkbook workbook, HSSFSheet sheet, ArrayList<Long> questionTimeArray, ArrayList<Long> answerTimeArray, 
			ArrayList<Long> deltaTimeArray, ArrayList<String> questionTextArray,  ArrayList<String> answerTextArray, ArrayList<Boolean> answerArray, ArrayList<Integer> edaMeasure) {

		workbook = new HSSFWorkbook();
		sheet = workbook.createSheet("EDA");

		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("Question Time");
		header.createCell(1).setCellValue("Question");
		header.createCell(2).setCellValue("Answer Time");
		header.createCell(3).setCellValue("Answer");
		header.createCell(4).setCellValue("Correct");
		header.createCell(5).setCellValue("delta");
		header.createCell(6).setCellValue("EDA");

		int rowCounter = 1;

		for(int i = 0; i < deltaTimeArray.size(); i++) {
			Row row = sheet.createRow(rowCounter);
			row.createCell(0).setCellValue(questionTimeArray.get(i));
			row.createCell(1).setCellValue(questionTextArray.get(i));
			row.createCell(2).setCellValue(answerTimeArray.get(i));
			row.createCell(3).setCellValue(answerTextArray.get(i));
			row.createCell(4).setCellValue(answerArray.get(i));
			row.createCell(5).setCellValue(deltaTimeArray.get(i));
			row.createCell(6).setCellValue(edaMeasure.get(i));
			rowCounter++;
		}



		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Save EDA");
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Excel file", ".xls");
		fileChooser.setFileFilter(filter);
		int userSelection = fileChooser.showSaveDialog(contentPane);

		if (userSelection == JFileChooser.APPROVE_OPTION) {
			File fileToSave = fileChooser.getSelectedFile();

			String excelFilePath = fileToSave.getAbsolutePath() + ".xls";
			try {
				FileOutputStream output = new FileOutputStream(excelFilePath);
				workbook.write(output);
				workbook.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		Plot graph = new Plot("EDA Measure", "Results", edaMeasure, questionTimeArray);
		graph.pack();
		graph.setVisible(true);

		
	}

	public static void compileArray(String answer, long answerTime, ArrayList<Long> questionTimeArray, ArrayList<Long> answerTimeArray, 
			ArrayList<Long> deltaTimeArray, ArrayList<String> questionTextArray,  ArrayList<String> answerTextArray, ArrayList<Boolean> answerArray, ArrayList<Integer> edaMeasure) {
		questionTimeArray.add(questionTime);
		answerTimeArray.add(answerTime);
		answerTextArray.add(answer);
		questionTextArray.add(question);
		answerArray.add(answer.toLowerCase().equals(question.toLowerCase()));
		deltaTimeArray.add(answerTime - questionTime);
		edaMeasure.add(SerialWriteRead.val);
	}

	public static void updateGraph(DynamicTimeSeriesChart chart) {
		timer = new Timer(500, new ActionListener() {


			@Override
			public void actionPerformed(ActionEvent e) {
				chart.update(SerialWriteRead.val);

			}
		}); 
		timer.start();
	}

}	
