package frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.fazecast.jSerialComm.SerialPort;

import plot.DynamicTimeSeriesChart;
import serial.Command;
import serial.SerialWriteRead;

public class StroopTestFrame extends JFrame implements ActionListener, FormSettings {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JPanel contentPane;

	/**
	 * Settings container variables
	 */

	private JButton getStateBtn;
	private JButton connectBtn;
	private JComboBox comPorts;
	private JLabel lblPort;
	private JCheckBox isConnectedCheckBox;
	private SerialPort serialPort;
	private JButton startStreamBtn;
	private JButton restartBtn;
	private JLabel stateSystemLabel;
	private JPanel commandsPanel;
	private JPanel settingsPanel;
	private JButton refreshBtn;
	
	private boolean wasStopped = false;
	
	/**
	 * game variables
	 */

	private JButton yellowAnswerBtn;
	private JButton greenAnswerBtn;
	private JButton redAnswerButton;
	private JButton blueAnswerButton;
	private JLabel questionLabel;
	private JButton playStopBtn;
	private JProgressBar progressBar;
	private JPanel answerPanel;
	public JPanel container;
	private JLabel lblGameDurationIn;
	private JSpinner gameLength;

	/**
	 * chart variables
	 */
	private DynamicTimeSeriesChart chart;

	/**
	 * xls variables
	 */

	private HSSFWorkbook workbook;
	private HSSFSheet sheet;

	private final Color colors[] = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW};
	private final String questions[] = {"RED", "BLUE", "GREEN", "YELLOW"};
	private int duration = 300000; //duration of the game in ms
	private int length = 5; //duration in minute

	private long questionTime;
	private long answerTime;
	private long startTime;

	private ArrayList<Long> questionTimeArray;
	private ArrayList<Long> answerTimeArray;
	private ArrayList<Boolean> answerArray;
	private ArrayList<Long> deltaTimeArray;
	private ArrayList<String> questionTextArray;
	private ArrayList<String> answerTextArray;
	private ArrayList<Integer> edaMeasure;
	private String question;



	/**
	 * Create the frame.
	 */
	public StroopTestFrame() {
		setTitle("EDA Measure");
		createFrame();

		attachSettingsComponents();

		setButtonProprietiesSettings();

		attachGameComponents();

		setButtonProprietiesGame();

	}

	@Override
	public void attachSettingsComponents() {

		settingsPanel = new JPanel();
		settingsPanel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		settingsPanel.setBounds(191, 77, 213, 72);
		contentPane.add(settingsPanel);
		settingsPanel.setLayout(null);

		lblPort = new JLabel("Port");
		lblPort.setBounds(165, 5, 36, 25);
		settingsPanel.add(lblPort);
		lblPort.setFont(new Font("Tahoma", Font.PLAIN, 20));

		isConnectedCheckBox = new JCheckBox("Connection");
		isConnectedCheckBox.setBounds(117, 44, 97, 23);
		settingsPanel.add(isConnectedCheckBox);
		isConnectedCheckBox.setEnabled(false);

		comPorts = new JComboBox();
		comPorts.setBounds(10, 6, 110, 30);
		settingsPanel.add(comPorts);

		comPorts.setModel(new DefaultComboBoxModel(SerialPort.getCommPorts()));

		commandsPanel = new JPanel();
		commandsPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		commandsPanel.setBounds(191, 160, 213, 107);
		contentPane.add(commandsPanel);
		commandsPanel.setLayout(null);
		

	}

	@Override
	public void setButtonProprietiesGame() {

		
		
		redAnswerButton = new JButton("RED");
		redAnswerButton.setBounds(10, 11, 131, 27);
		answerPanel.add(redAnswerButton);
		redAnswerButton.setEnabled(false);

		blueAnswerButton = new JButton("BLUE");
		blueAnswerButton.setBounds(160, 11, 131, 27);
		answerPanel.add(blueAnswerButton);
		blueAnswerButton.setEnabled(false);


		greenAnswerBtn = new JButton("GREEN");
		greenAnswerBtn.setBounds(310, 11, 131, 27);
		answerPanel.add(greenAnswerBtn);
		greenAnswerBtn.setEnabled(false);

		yellowAnswerBtn = new JButton("YELLOW");
		yellowAnswerBtn.setBounds(451, 11, 131, 27);
		answerPanel.add(yellowAnswerBtn);
		yellowAnswerBtn.setEnabled(false);
		
		yellowAnswerBtn.setFocusable(true);
		greenAnswerBtn.setFocusable(true);
		blueAnswerButton.setFocusable(true);
		redAnswerButton.setFocusable(true);

		yellowAnswerBtn.addActionListener(this);
		greenAnswerBtn.addActionListener(this);
		blueAnswerButton.addActionListener(this);
		redAnswerButton.addActionListener(this);


	}

	@Override
	public void setButtonProprietiesSettings() {

		getStateBtn = new JButton("Get System State");
		getStateBtn.setEnabled(false);
		getStateBtn.setBounds(10, 45, 193, 23);
		commandsPanel.add(getStateBtn);
		getStateBtn.addActionListener(this);

		startStreamBtn = new JButton("Start EDA Activity");
		startStreamBtn.setEnabled(false);
		startStreamBtn.setBounds(10, 74, 193, 23);
		commandsPanel.add(startStreamBtn);
		startStreamBtn.addActionListener(this);

		restartBtn = new JButton("Restart System");
		restartBtn.setEnabled(false);
		restartBtn.setBounds(10, 11, 193, 23);
		commandsPanel.add(restartBtn);
		restartBtn.addActionListener(this);

		stateSystemLabel = new JLabel("State: ");
		stateSystemLabel.setBounds(414, 179, 231, 59);
		contentPane.add(stateSystemLabel);
		getStateBtn.addActionListener(this);

		connectBtn = new JButton("Connect");
		connectBtn.setBounds(10, 44, 89, 23);
		settingsPanel.add(connectBtn);
		connectBtn.addActionListener(this);

		refreshBtn = new JButton("");
		refreshBtn.setIcon(new ImageIcon(StroopTestFrame.class.getResource("/com/sun/javafx/scene/web/skin/Redo_16x16_JFX.png")));
		refreshBtn.setBounds(130, 8, 25, 26);
		settingsPanel.add(refreshBtn);
		refreshBtn.addActionListener(this);

	}
	@Override
	public void createFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1875, 893);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// manage connectBtn
		if(e.getSource() == connectBtn) {
			serialPort = SerialPort.getCommPorts()[comPorts.getSelectedIndex()];
			serialPort.openPort();
			if(serialPort.isOpen()) {
				isConnectedCheckBox.setSelected(true);
				connectBtn.setEnabled(false);				
				comPorts.setEnabled(false);
				startStreamBtn.setEnabled(true);
				restartBtn.setEnabled(true);
				getStateBtn.setEnabled(true);
				refreshBtn.setEnabled(false);
			}
		}

		//restart system
		if(e.getSource() == restartBtn) {
			byte cmd = Command.CMD_RESTART.getCmdByte();
			byte r_w = Command.WRITE.getCmdByte();
			byte len = 0;

			SerialWriteRead.getInstance(serialPort).sendCmd(cmd, r_w, len);
			//SerialWriteRead.getInstance().readStateFromSerial(serialPort);	
		}

		//get state
		if(e.getSource() == getStateBtn) {

			byte cmd = Command.CMD_STATE.getCmdByte();
			byte r_w = Command.READ.getCmdByte();
			byte len = 0;

			SerialWriteRead.getInstance(serialPort).sendCmd(cmd, r_w, len);
			stateSystemLabel.setText("State: " + SerialWriteRead.getInstance(serialPort).readStateFromSerial());	
			
		}

		//start stream
		if(e.getSource() == startStreamBtn) {
			
			if(startStreamBtn.getText().equals("Stop Stream")) {
				byte cmd = Command.CMD_STOP_STREAM.getCmdByte();
				byte r_w = Command.WRITE.getCmdByte();
				byte len = 0;
				
				SerialWriteRead.getInstance(serialPort).sendCmd(cmd, r_w, len);
				startStreamBtn.setText("Start EDA Activity");
				restartBtn.setEnabled(true);
				container.setVisible(false);
				chart.setVisible(false);
			}
			else {
				restartBtn.setEnabled(false);
				startStreamBtn.setText("Stop Stream");
				chart.setVisible(true);
				playStopBtn.setVisible(true);
				gameLength.setVisible(true);
				lblGameDurationIn.setVisible(true);
				container.setVisible(true);
				
				
				
				byte cmd = Command.CMD_STREAM.getCmdByte();
				byte r_w = Command.READ.getCmdByte();
				byte len = 0;
				SerialWriteRead.getInstance(serialPort).sendCmd(cmd, r_w, len);
				SerialWriteRead.getInstance(serialPort).readEDA();
								
			}
			
		}

		if(e.getSource() == refreshBtn) {
			comPorts.setModel(new DefaultComboBoxModel(SerialPort.getCommPorts()));
		}


		if(e.getSource() == playStopBtn) {
			if(playStopBtn.getText().equals("PLAY")) {
				Game.startGame(chart, contentPane, workbook, sheet, edaMeasure, questionTimeArray, answerTimeArray, deltaTimeArray, questionTextArray, answerTextArray, answerArray, System.currentTimeMillis(), gameLength, progressBar, answerPanel, playStopBtn, lblGameDurationIn, redAnswerButton, greenAnswerBtn, yellowAnswerBtn, blueAnswerButton, serialPort);			
				Game.chooseQuestion(colors, questions, questionLabel);

				chart.setVisible(true);
				lblGameDurationIn.setVisible(false);
				gameLength.setVisible(false);
				
				if(wasStopped) {
					
					questionTimeArray.clear();
					answerTimeArray.clear();
					answerArray.clear();
					deltaTimeArray.clear();
					questionTextArray.clear();
					answerTextArray.clear();
					edaMeasure.clear();
					
					Game.timer.restart();
					Game.gameTime.resume();
					SerialWriteRead.reader.resume();
					
					chart = new DynamicTimeSeriesChart("EDA Measure");
					chart.setBounds(709, 11, 1140, 824);
					contentPane.add(chart);
					
				}
			}
			else {
				
				byte cmd = Command.CMD_STOP_STREAM.getCmdByte();
				byte r_w = Command.WRITE.getCmdByte();
				byte len = 0;
				
				SerialWriteRead.getInstance(serialPort).sendCmd(cmd, r_w, len);
				startStreamBtn.setText("Start EDA Activity");
				restartBtn.setEnabled(true);
				container.setVisible(false);
				chart.setVisible(false);
				
				
				wasStopped = true;
				Game.gameTime.interrupt();
				SerialWriteRead.reader.interrupt();
				Game.timer.stop();
				playStopBtn.setText("PLAY");
				gameLength.setVisible(true);
				lblGameDurationIn.setVisible(true);
				
				
				
			}
		}

		if(e.getSource() == redAnswerButton) {
			answerTime = System.currentTimeMillis();
			Game.compileArray(redAnswerButton.getText(), System.currentTimeMillis(), questionTimeArray, answerTimeArray, deltaTimeArray, questionTextArray, answerTextArray, answerArray, edaMeasure);
			Game.chooseQuestion(colors, questions, questionLabel);
		}

		if(e.getSource() == blueAnswerButton) {
			answerTime = System.currentTimeMillis();
			Game.compileArray(blueAnswerButton.getText(), System.currentTimeMillis(), questionTimeArray, answerTimeArray, deltaTimeArray, questionTextArray, answerTextArray, answerArray, edaMeasure);
			Game.chooseQuestion(colors, questions, questionLabel);
		}

		if(e.getSource() == greenAnswerBtn) {
			answerTime = System.currentTimeMillis();
			Game.compileArray(greenAnswerBtn.getText(), System.currentTimeMillis(), questionTimeArray, answerTimeArray, deltaTimeArray, questionTextArray, answerTextArray, answerArray, edaMeasure);
			Game.chooseQuestion(colors, questions, questionLabel);
		}

		if(e.getSource() == yellowAnswerBtn) {
			answerTime = System.currentTimeMillis();
			Game.compileArray(yellowAnswerBtn.getText(), System.currentTimeMillis(), questionTimeArray, answerTimeArray, deltaTimeArray, questionTextArray, answerTextArray, answerArray, edaMeasure);
			Game.chooseQuestion(colors, questions, questionLabel);
		}
	}

	@Override
	public void attachGameComponents() {
		container = new JPanel();
		container.setBorder(null);
		container.setForeground(Color.RED);
		container.setBounds(10, 361, 635, 474);
		contentPane.add(container);
		container.setLayout(null);

		playStopBtn = new JButton("PLAY");
		playStopBtn.setBounds(514, 11, 110, 33);
		container.add(playStopBtn);
		
		questionLabel = new JLabel("");
		questionLabel.setBounds(10, 156, 591, 161);
		container.add(questionLabel);
		questionLabel.setHorizontalAlignment(SwingConstants.CENTER);
		questionLabel.setFont(new Font("Arial", Font.BOLD, 50));

		progressBar = new JProgressBar();
		progressBar.setBackground(Color.WHITE);
		progressBar.setBounds(10, 122, 614, 23);
		container.add(progressBar);
		progressBar.setForeground(Color.GREEN);
		progressBar.setVisible(false);

		answerPanel = new JPanel();
		answerPanel.setBounds(10, 405, 614, 58);
		container.add(answerPanel);
		answerPanel.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		answerPanel.setLayout(null);
		answerPanel.setVisible(false);

		gameLength = new JSpinner();
		gameLength.setBounds(10, 11, 109, 67);
		container.add(gameLength);
		gameLength.setFont(new Font("Tahoma", Font.PLAIN, 20));
		gameLength.setModel(new SpinnerNumberModel(5, 1, 5, 1));

		lblGameDurationIn = new JLabel("Game duration \r\n in minutes");
		lblGameDurationIn.setBounds(129, 35, 253, 28);
		container.add(lblGameDurationIn);
		lblGameDurationIn.setVerticalAlignment(SwingConstants.TOP);
		lblGameDurationIn.setHorizontalAlignment(SwingConstants.LEFT);
		lblGameDurationIn.setFont(new Font("Arial Black", Font.BOLD, 15));
		playStopBtn.addActionListener(this);


		//
		questionTimeArray = new ArrayList<Long>();
		answerTimeArray = new ArrayList<Long>();
		answerArray = new ArrayList<Boolean>();
		deltaTimeArray = new ArrayList<Long>();
		questionTextArray = new ArrayList<String>();
		answerTextArray = new ArrayList<String>();
		edaMeasure = new ArrayList<Integer>();
		//

		chart = new DynamicTimeSeriesChart("EDA Measure");
		chart.setBounds(709, 11, 1140, 824);
		contentPane.add(chart);
		
		chart.setVisible(false);
		lblGameDurationIn.setVisible(false);
		gameLength.setVisible(false);
		playStopBtn.setVisible(false);
	}


}
