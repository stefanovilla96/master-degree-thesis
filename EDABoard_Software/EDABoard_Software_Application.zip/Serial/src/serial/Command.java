package serial;

public enum Command {

	CMD_RESTART("Restart", (byte) 0x00),
	CMD_STATE("Get State", (byte) 0x01),
	CMD_STREAM("Stream EDA Data", (byte) 0x02),
	CMD_STOP_STREAM("STOP Stream", (byte) 0x03),
	
	WRITE("Write", (byte) 0x00),
	READ("Read", (byte) 0x80),
	
	ACK_CODE("ACK_Code", (byte) 0x00),
	
	ACK_SUCCESS("ACK_Success", (byte) 0x00),
	
	STARTUP("STARTUP", (byte) 0x00),
	IDLE("IDLE", (byte) 0x01),
	STREAM("STREAM", (byte) 0x02),
	ERROR("ERROR", (byte) 0xFF);
	
	private final String cmdName;
	private final byte cmdByte;

	private Command(String cmdName, byte cmd)
    {
        this.cmdName = cmdName;
        this.cmdByte = cmd;
    }
	
	public byte getCmdByte() {
		return cmdByte;
	}
	
	public String getCmdName() {
		return cmdName;
	}
}
