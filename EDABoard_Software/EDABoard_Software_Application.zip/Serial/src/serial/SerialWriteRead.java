package serial;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import com.fazecast.jSerialComm.SerialPort;

public class SerialWriteRead implements SerialIO{

	private static SerialWriteRead instance;
	private FileWriter writer;
	private BufferedWriter bufferedWriter;
	public static Thread reader;

	public static int val;
	private SerialPort serialPort;

	private SerialWriteRead(SerialPort serialPort) {
		this.serialPort = serialPort;

	}

	public static SerialWriteRead getInstance(SerialPort serialPort) {

		if(instance == null) {
			instance = new SerialWriteRead(serialPort);
			return instance;
		}
		return instance;
	}


	private boolean checkSyntax(byte[] buffer, int numRead) {
		if(buffer[0] == Packet.getHEADER() && buffer[1] == Packet.getHEADER()){
			if(buffer[numRead - 1] == Packet.getTRAILER() && buffer[numRead - 2] == Packet.getTRAILER()) {
				if(buffer[2] == Command.ACK_CODE.getCmdByte()) {
					if(buffer[5] == Command.ACK_SUCCESS.getCmdByte()) {
						return true;
					}
				}
			}	
		}
		return false;
	}

	/////////////////////////////////////////////////////////

	@Override
	public String readStateFromSerial() {
		try {
			if (serialPort.bytesAvailable() == 0) {
				Thread.sleep(100);
			}

			byte[] readBuffer = new byte[serialPort.bytesAvailable()];
			int numRead = serialPort.readBytes(readBuffer, readBuffer.length);

			if(checkSyntax(readBuffer, numRead)) {
				System.out.println("Response - STATE: OK -> " + readBuffer[6]);
				switch (readBuffer[6]) {
				case 0:

					return Command.STARTUP.getCmdName();
				case 1:
					return Command.IDLE.getCmdName();
				case 2:
					return Command.STREAM.getCmdName();

				default:
					return "undefined";
				}
			}
			else {
				System.err.println("Wrong format");
				return "undefined";
			}

		} catch (Exception ex) { ex.printStackTrace(); }
		return "undefined";
	}

	@Override
	public void sendCmd(byte cmd, byte w_r, byte len) {
		System.err.println("Send: " + cmd);
		cmd = (byte) (cmd | w_r);
		byte header = (byte) Packet.getHEADER();
		byte trailer = (byte) Packet.getTRAILER();
		byte tx[] = {header, header, cmd, len, trailer, trailer};
		serialPort.writeBytes(tx, tx.length);

	}

	@Override
	public void readEDA() {

		reader = new Thread() {
			public void run() {
				
				try {
					writer = new FileWriter("eda_" + new Date().getTime() + ".txt");
					bufferedWriter = new BufferedWriter(writer);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				try {
					bufferedWriter.write("" + System.currentTimeMillis());
					bufferedWriter.newLine();
					bufferedWriter.newLine();
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				while(true) {

					if(serialPort.bytesAvailable() != 0) {
						byte[] readBuffer = new byte[serialPort.bytesAvailable()];
						int numRead = serialPort.readBytes(readBuffer, readBuffer.length);
						int v = findPacket(readBuffer, numRead);
						if(0 > 1) {
							break;
						}

						try {
							bufferedWriter.write("" + v);
							bufferedWriter.newLine();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
					
					
				}
				try {
					bufferedWriter.close();
				} catch (IOException e) {
					e.printStackTrace();
				}


			}

		};
		reader.start();

	}

	private int findPacket(byte[] readBuffer, int numRead) {

		try{

			for(int i = 0; i < numRead; i++) {
				//System.out.println(i);
				if(readBuffer[i] == Packet.getHEADER() && readBuffer[i + 1] == Packet.getHEADER()) {
					if(readBuffer[i + 8] == Packet.getTRAILER() && readBuffer[i + 9] == Packet.getTRAILER()){
						//System.err.println("Pacchetto!");
						byte length = readBuffer[i + 3];
						Packet p = new Packet(length);
						byte payload[] = new byte[length];
						payload[0] = (readBuffer[i + 4]);
						payload[1] = (readBuffer[i + 5]);
						payload[2] = (readBuffer[i + 6]);
						payload[3] = (readBuffer[i + 7]);
						p.setPayload(payload);
						SerialWriteRead.val = ((payload[0] & 0xFF) << 8) | (payload[1] & 0xFF);
						int val2 = ((payload[2] & 0xFF) << 8) | (payload[3] & 0xFF);
						p.setValue(val);
						System.out.println(p.getValue() + " ------ "+ val2);

						i = i + 10;

					}
				}
			}
		}catch (Exception e) {
			System.out.println("Corto!");
		}
		finally {
			
		}

		return SerialWriteRead.val;

	}

}
