package serial;

public class Packet {
	
	private final static char HEADER = '<';
	private final static char TRAILER = '>';
	
	private byte command;
	private byte length;
	private byte[] payload;
	private int value;
	
	public Packet(byte length) {
		this.length = length;
		payload = new byte[length];
	}
	
	public byte getCommand() {
		return command;
	}
	
	public static char getHEADER() {
		return HEADER;
	}
	
	public static char getTRAILER() {
		return TRAILER;
	}
	
	public byte getLength() {
		return length;
	}
	
	public byte[] getPayload() {
		return payload;
	}
	
	public void setCommand(byte command) {
		this.command = command;
	}
	
	public void setLength(byte length) {
		this.length = length;
	}
	
	public void setPayload(byte[] payload) {
		this.payload = payload;
	}
	
	public int getValue() {
		return value;
	}
	
	public void setValue(int value) {
		this.value = value;
	}
}
