package serial;

public interface SerialIO {
	public String readStateFromSerial();
	public void readEDA();
	public void sendCmd(byte cmd, byte w_r, byte len);

}
