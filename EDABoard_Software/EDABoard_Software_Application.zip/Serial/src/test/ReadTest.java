package test;

import com.fazecast.jSerialComm.SerialPort;

public class ReadTest {

	public static void main(String[] args) {
		SerialPort serialPort = SerialPort.getCommPort("COM11");
		try {
			while (true) {

				while (serialPort.bytesAvailable() == 0) {
					Thread.sleep(100);
				}

				byte[] readBuffer = new byte[serialPort.bytesAvailable()];
				int numRead = serialPort.readBytes(readBuffer, readBuffer.length);
				System.out.println(numRead);
				


			}
		} catch (Exception ex) { ex.printStackTrace(); }
	}
}
