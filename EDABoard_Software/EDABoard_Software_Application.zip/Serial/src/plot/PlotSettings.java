package plot;

import java.util.ArrayList;

import org.jfree.data.xy.XYDataset;

public interface PlotSettings {
	public void update(int v);
	public XYDataset createDataset(ArrayList<Integer> eda, ArrayList<Long> questionTime);
	
}
