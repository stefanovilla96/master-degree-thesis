package plot;

import java.awt.Color;
import java.util.ArrayList;
import java.awt.BasicStroke; 

import org.jfree.chart.ChartPanel; 
import org.jfree.chart.JFreeChart; 
import org.jfree.data.xy.XYDataset; 
import org.jfree.data.xy.XYSeries; 
import org.jfree.chart.ui.ApplicationFrame; 
//import org.jfree.ui.RefineryUtilities; 
import org.jfree.chart.plot.XYPlot; 
import org.jfree.chart.ChartFactory; 
import org.jfree.chart.plot.PlotOrientation; 
import org.jfree.data.xy.XYSeriesCollection; 
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;

public class Plot extends ApplicationFrame implements PlotSettings {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Plot( String applicationTitle, String chartTitle, ArrayList<Integer> eda, ArrayList<Long> questionTime) {
		super(applicationTitle);
		JFreeChart xylineChart = ChartFactory.createXYLineChart(
				chartTitle ,
				"Time" ,
				"EDA" ,
				createDataset(eda, questionTime) ,
				PlotOrientation.VERTICAL ,
				true , true , false);

		ChartPanel chartPanel = new ChartPanel( xylineChart );
		chartPanel.setPreferredSize( new java.awt.Dimension( 560 , 367 ) );
		final XYPlot plot = xylineChart.getXYPlot( );

		//XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer( );
		//renderer.setSeriesPaint( 0 , Color.RED );
		//renderer.setSeriesPaint( 1 , Color.GREEN );
		//renderer.setSeriesStroke( 0 , new BasicStroke( 4.0f ) );
		//renderer.setSeriesStroke( 1 , new BasicStroke( 3.0f ) );
		//plot.setRenderer( renderer ); 
		setContentPane( chartPanel ); 
	}

	@Override
	public XYDataset createDataset(ArrayList<Integer> eda, ArrayList<Long> questionTime) {
		final XYSeries series1 = new XYSeries( "EDA" );          
		for(int i = 0; i < eda.size(); i++) {
			series1.add(questionTime.get(i), eda.get(i));

		}

		final XYSeriesCollection dataset = new XYSeriesCollection( );                  

		dataset.addSeries( series1 );
		return dataset;
	}

	@Override
	public void update(int v) {
		// TODO Auto-generated method stub
		
	}
}