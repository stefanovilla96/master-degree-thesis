package plot;

import java.awt.BasicStroke;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.DynamicTimeSeriesCollection;
import org.jfree.data.time.Second;
import org.jfree.data.xy.XYDataset;

/**
 * @see https://stackoverflow.com/a/21307289/230513
 */
public class DynamicTimeSeriesChart extends JPanel implements PlotSettings{

    private final DynamicTimeSeriesCollection dataset;
    private final JFreeChart chart;

    public DynamicTimeSeriesChart(final String title) {
        dataset = new DynamicTimeSeriesCollection(1, 30, new Second());
        dataset.setTimeBase(new Second(0, 0, 0, 7, 2, 2020));
        dataset.addSeries(new float[1], 0, title);
        chart = ChartFactory.createTimeSeriesChart(
            title, "Time", title, dataset, true, true, false);
        final XYPlot plot = chart.getXYPlot();
        
        
        ValueAxis domain = plot.getDomainAxis();
        domain.setAutoRange(true);
        ValueAxis range = plot.getRangeAxis();
        range.setRange(0, 100);
        
        
        //y axis
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis(); 
        rangeAxis.setRange(0, 5000); 
        rangeAxis.setTickUnit(new NumberTickUnit(250)); 
        
        
        
        final ChartPanel chartPanel = new ChartPanel(chart);
        add(chartPanel);
    }

	public void update(int v) {
        float[] newData = new float[1];
        newData[0] = v;
        dataset.advanceTime();
        dataset.appendData(newData);
    }

	@Override
	public XYDataset createDataset(ArrayList<Integer> eda, ArrayList<Long> questionTime) {
		// TODO Auto-generated method stub
		return null;
	}

    
    
}